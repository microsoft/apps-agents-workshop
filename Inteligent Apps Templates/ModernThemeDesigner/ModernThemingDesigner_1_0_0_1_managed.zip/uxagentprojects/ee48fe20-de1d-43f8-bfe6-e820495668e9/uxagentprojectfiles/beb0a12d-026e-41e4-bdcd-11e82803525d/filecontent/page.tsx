import React, { useState, useMemo, useEffect } from 'react';
import {
    Button,
    Text,
    Input,
    Switch,
    Slider,
    Textarea,
    makeStyles,
    tokens,
    Card,
    CardHeader,
    CardFooter,
    Field,
    Dropdown,
    Option,
    Persona,
    Checkbox,
    RadioGroup,
    Radio,
    TabList,
    Tab,
    Link,
    FluentProvider,
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn,
    Toaster,
    useToastController,
    Toast,
    ToastTitle
} from '@fluentui/react-components';
import { SaveRegular, SearchRegular } from '@fluentui/react-icons';
import { webLightTheme, BrandVariants, createLightTheme } from '@fluentui/react-components';

const useStyles = makeStyles({
    pageContainer: {
        display: 'flex',
        flexDirection: 'column',
        width: '100%',
        height: '100%',
        boxSizing: 'border-box',
        padding: tokens.spacingHorizontalM,
        gap: tokens.spacingVerticalL
    },
    topSection: {
        display: 'flex',
        flexDirection: 'row',
        gap: tokens.spacingHorizontalL,
        flex: 1,
        height: '100%',
        '@media (max-width: 768px)': {
            flexDirection: 'column'
        }
    },
    controlsCard: {
        flex: '0 0 320px',
        display: 'flex',
        flexDirection: 'column',
        gap: tokens.spacingVerticalM,
        minHeight: 0,
        height: '100%'
    },
    previewCard: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: tokens.spacingVerticalM,
        overflow: 'auto',
        height: '100%'
    },
    colorInput: {
        width: '100%',
        height: '32px',
        border: 'none',
        padding: 0,
        cursor: 'pointer'
    },
    paletteContainer: {
        display: 'flex',
        flexWrap: 'wrap',
        gap: tokens.spacingHorizontalS
    },
    paletteBox: {
        width: '48px',
        height: '48px',
        borderRadius: tokens.borderRadiusSmall,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '12px',
        color: 'white',
        fontWeight: 600,
        boxShadow: tokens.shadow4
    },
    previewBox: {
        display: 'flex',
        flexDirection: 'column',
        borderRadius: tokens.borderRadiusMedium,
        padding: tokens.spacingHorizontalL,
        textAlign: 'left',
        gap: tokens.spacingVerticalM,
        minHeight: '200px'
    },
    xmlFieldContainer: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        minHeight: 0
    },
    xmlTextarea: {
        flex: 1,
        width: '100%',
        resize: 'none'
    },
    sliderContainer: {
        display: 'flex',
        flexDirection: 'column',
        gap: tokens.spacingVerticalXS
    },
    swatchBox: {
        display: 'inline-block',
        width: '16px',
        height: '16px',
        borderRadius: '4px',
        marginRight: '8px',
        verticalAlign: 'middle'
    },
    previewGrid: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: tokens.spacingHorizontalL,
        alignItems: 'flex-start'
    },
    section: {
        display: 'flex',
        flexDirection: 'column',
        gap: tokens.spacingVerticalS
    },
    personaSection: {
        display: 'flex',
        alignItems: 'center',
        gap: tokens.spacingHorizontalS
    },
    switchesRow: {
        display: 'flex',
        gap: tokens.spacingHorizontalL,
        alignItems: 'center'
    },
    tabsRow: {
        marginTop: tokens.spacingVerticalS
    },
    requiredMark: {
        color: tokens.colorPaletteRedForeground1,
        marginLeft: '4px'
    },
    fullWidthGridContainer: {
        width: '100%',
        padding: tokens.spacingHorizontalM,
        boxSizing: 'border-box'
    }
});

function useDebounce<T>(value: T, delay: number): T {
    const [debouncedValue, setDebouncedValue] = useState(value);
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);
    return debouncedValue;
}

function normalizeHexColor(value: string): string {
    if (!value) return '#0078D4';
    let hex = value.trim();
    if (!hex.startsWith('#')) {
        hex = `#${hex}`;
    }
    if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
        return hex;
    }
    return '#0078D4';
}

function hexToHsl(hex: string): { h: number; s: number; l: number } {
    hex = hex.replace(/^#/, '');
    if (hex.length === 3) {
        hex = hex.split('').map(x => x + x).join('');
    }
    const r = parseInt(hex.substring(0, 2), 16) / 255;
    const g = parseInt(hex.substring(2, 4), 16) / 255;
    const b = parseInt(hex.substring(4, 6), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }
    return { h: h * 360, s: s * 100, l: l * 100 };
}

function hslToHex(h: number, s: number, l: number): string {
    s /= 100;
    l /= 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;

    if (h >= 0 && h < 60) { r = c; g = x; b = 0; }
    else if (h >= 60 && h < 120) { r = x; g = c; b = 0; }
    else if (h >= 120 && h < 180) { r = 0; g = c; b = x; }
    else if (h >= 180 && h < 240) { r = 0; g = x; b = c; }
    else if (h >= 240 && h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }

    const toHex = (n: number) => {
        const hex = Math.round((n + m) * 255).toString(16).padStart(2, '0');
        return hex;
    };

    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function generateBrandVariantsFromHex(baseColor: string): BrandVariants {
    const { h, s, l } = hexToHsl(baseColor);
    const variants: BrandVariants = {} as BrandVariants;
    const steps = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160];
    steps.forEach((step, index) => {
        const lightness = Math.max(0, Math.min(100, l + (index - 8) * 5));
        variants[step as keyof BrandVariants] = hslToHex(h, s, lightness);
    });
    return variants;
}

function updateWebResource(webResourceId: string, newContent: string, newDisplayName?: string) {
    if (!webResourceId || typeof webResourceId !== "string") {
        console.error("Invalid webResourceId");
        return;
    }
    if (typeof newContent !== "string" || newContent.trim() === "") {
        console.error("Invalid newContent");
        return;
    }

    const base64Content = btoa(newContent);
    const updateData: any = { content: base64Content };
    if (newDisplayName) {
        updateData.displayname = newDisplayName;
    }

    Xrm.WebApi.updateRecord("webresource", webResourceId, updateData).then(
        function success(result) {
            console.log(`Web resource updated. ID: ${result.id}`);
            publishWebResource(webResourceId);
        },
        function (error) {
            console.error("Error updating web resource:", error.message);
        }
    );
}

function publishWebResource(webResourceId: string) {
    const publishXml = `<importexportxml><webresources><webresource>{${webResourceId}}</webresource></webresources></importexportxml>`;
    const request = {
        ParameterXml: publishXml,
        getMetadata: function () {
            return {
                boundParameter: null,
                parameterTypes: {
                    "ParameterXml": { typeName: "Edm.String", structuralProperty: 1 }
                },
                operationType: 0,
                operationName: "PublishXml"
            };
        }
    };

    Xrm.WebApi.execute(request).then(
        function success() {
            console.log("Web resource published successfully.");
        },
        function (error) {
            console.error("Error publishing web resource:", error.message);
        }
    );
}

const GeneratedComponent: React.FC = () => {
    const styles = useStyles();
    const { dispatchToast } = useToastController();

    const [brandColor, setBrandColor] = useState('#0078D4');
    const [baseColorInput, setBaseColorInput] = useState('#0078D4');
    const [hueTorsion, setHueTorsion] = useState(0);
    const [vibrancy, setVibrancy] = useState(50);
    const [lockPrimary, setLockPrimary] = useState(false);
    const [selectedFont, setSelectedFont] = useState('Segoe UI');
    const [selectedPresetColorName, setSelectedPresetColorName] = useState<string | undefined>(undefined);
    const [webResourceId, setWebResourceId] = useState<string | null>(null);
    const [loadedXml, setLoadedXml] = useState('');

    const fonts = [
        'Segoe UI', 'Arial', 'Calibri', 'Verdana', 'Tahoma',
        'Times New Roman', 'Georgia', 'Consolas', 'Courier New',
        'Trebuchet MS', 'Comic Sans MS'
    ];

    const debouncedBrandColor = useDebounce(brandColor, 300);
    const debouncedHueTorsion = useDebounce(hueTorsion, 300);
    const debouncedVibrancy = useDebounce(vibrancy, 300);
    const debouncedLockPrimary = useDebounce(lockPrimary, 300);
    const debouncedFont = useDebounce(selectedFont, 300);

    const presetColors = [
        { name: 'Power Apps', color: '#742774' },        
        { name: 'Blue', color: '#185ABD' },
        { name: 'Green', color: '#107C41' },
        { name: 'Red', color: '#D24726' },
        { name: 'Brown', color: '#964B00' },
        { name: 'Charcoal', color: '#222222' },
        { name: 'Fuscia', color: '#BC1948' },
        { name: 'Purple', color: '#6264A7' },
        { name: 'Grey', color: '#989EA1' }
    ];

    useEffect(() => {
        const loadTheme = async () => {
            try {
                const result = await Xrm.WebApi.retrieveMultipleRecords("webresource", "?$filter=name eq 'pwrcat_CustomTheme'");
                if (result.entities.length > 0) {
                    const resource = result.entities[0];
                    const base64Content = resource.content;
                    const id = resource.webresourceid;
                    if (id) {
                        setWebResourceId(id);
                    }
                    if (base64Content) {
                        const decodedContent = atob(base64Content);
                        setLoadedXml(decodedContent);
                        const parser = new DOMParser();
                        const xmlDoc = parser.parseFromString(decodedContent, "application/xml");
                        const customThemeNode = xmlDoc.getElementsByTagName("CustomTheme")[0];

                        if (customThemeNode) {
                            const basePaletteColorAttr = customThemeNode.getAttribute("basePaletteColor");
                            const hueAttr = customThemeNode.getAttribute("hueTorsion");
                            const vibrancyAttr = customThemeNode.getAttribute("vibrancy");
                            const lockPrimaryAttr = customThemeNode.getAttribute("lockPrimary");
                            const fontAttr = customThemeNode.getAttribute("font");

                            if (basePaletteColorAttr) {
                                const normalized = normalizeHexColor(basePaletteColorAttr);
                                setBrandColor(normalized);
                                setBaseColorInput(normalized);
                            }
                            if (hueAttr) {
                                const parsedHue = parseInt(hueAttr.trim(), 10);
                                if (!isNaN(parsedHue)) setHueTorsion(parsedHue);
                            }
                            if (vibrancyAttr) {
                                const parsedVibrancy = parseInt(vibrancyAttr.trim(), 10);
                                if (!isNaN(parsedVibrancy)) setVibrancy(parsedVibrancy);
                            }
                            if (lockPrimaryAttr) {
                                setLockPrimary(lockPrimaryAttr.toLowerCase() === "true");
                            }
                            if (fontAttr) {
                                setSelectedFont(fontAttr);
                            }
                        }
                    }
                } else {
                    console.warn("pwrcat_CustomTheme web resource not found.");
                }
            } catch (error) {
                console.error("Error loading theme:", error);
            }
        };
        loadTheme();
    }, []);

    useEffect(() => {
        setBaseColorInput(brandColor);
        const match = presetColors.find(pc => pc.color.toLowerCase() === brandColor.toLowerCase());
        setSelectedPresetColorName(match ? match.name : undefined);
    }, [brandColor]);

    useEffect(() => {
        if (!fonts.includes(selectedFont)) {
            setSelectedFont('Segoe UI');
        }
    }, [selectedFont]);

    const brandVariants: BrandVariants = useMemo(() => generateBrandVariantsFromHex(debouncedBrandColor), [debouncedBrandColor]);
    const previewBrandVariants: BrandVariants = useMemo(() => generateBrandVariantsFromHex(brandColor), [brandColor]);

    const theme = useMemo(() => {
        const baseTheme = createLightTheme(brandVariants);
        baseTheme.fontFamilyBase = debouncedFont;
        (baseTheme as any).__customHueTorsion = debouncedHueTorsion;
        (baseTheme as any).__customVibrancy = debouncedVibrancy;
        (baseTheme as any).__customLockPrimary = debouncedLockPrimary;
        return baseTheme;
    }, [brandVariants, debouncedFont, debouncedHueTorsion, debouncedVibrancy, debouncedLockPrimary]);

    const previewTheme = useMemo(() => {
        const baseTheme = createLightTheme(previewBrandVariants);
        baseTheme.fontFamilyBase = selectedFont;
        (baseTheme as any).__customHueTorsion = hueTorsion;
        (baseTheme as any).__customVibrancy = vibrancy;
        (baseTheme as any).__customLockPrimary = lockPrimary;
        return baseTheme;
    }, [previewBrandVariants, selectedFont, hueTorsion, vibrancy, lockPrimary]);

    const handleBaseColorBlur = () => {
        const normalized = normalizeHexColor(baseColorInput);
        setBrandColor(normalized);
        setBaseColorInput(normalized);
    };

    const handleSaveTheme = () => {
        const xmlString = `<CustomTheme basePaletteColor="${debouncedBrandColor}" vibrancy="${debouncedVibrancy}" hueTorsion="${debouncedHueTorsion}" lockPrimary="${debouncedLockPrimary}" font="${debouncedFont}" />`;

        if (webResourceId) {
            updateWebResource(webResourceId, xmlString);
        } else {
            console.error("Web resource ID is not available. Cannot save theme.");
        }

        dispatchToast(
            <Toast>
                <ToastTitle>Theme saved successfully!</ToastTitle>
            </Toast>,
            { intent: 'success' }
        );
    };

    const paletteKeys = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160];

    const gridItems = [
        { id: '1', name: 'Alice Johnson', role: 'Designer', status: 'Active' },
        { id: '2', name: 'Bob Smith', role: 'Developer', status: 'Inactive' },
        { id: '3', name: 'Charlie Brown', role: 'Manager', status: 'Active' },
        { id: '4', name: 'Diana Prince', role: 'Analyst', status: 'Active' },
        { id: '5', name: 'Ethan Hunt', role: 'Consultant', status: 'Inactive' }
    ];

    const columns = [
        createTableColumn({
            columnId: 'name',
            renderHeaderCell: () => 'Name',
            renderCell: (item: any) => <TableCellLayout>{item.name}</TableCellLayout>
        }),
        createTableColumn({
            columnId: 'role',
            renderHeaderCell: () => 'Role',
            renderCell: (item: any) => <TableCellLayout>{item.role}</TableCellLayout>
        }),
        createTableColumn({
            columnId: 'status',
            renderHeaderCell: () => 'Status',
            renderCell: (item: any) => <TableCellLayout>{item.status}</TableCellLayout>
        }),
        createTableColumn({
            columnId: 'action',
            renderHeaderCell: () => 'Action',
            renderCell: () => <Link href="#">More Info</Link>
        })
    ];

    return (
        <FluentProvider theme={previewTheme} style={{ width: '100%', height: '100%', fontFamily: selectedFont }}>
            <Toaster position="top" />
            <div className={styles.pageContainer}>
                <div className={styles.topSection}>
                    <FluentProvider theme={previewTheme} style={{ flex: '0 0 320px' }}>
                        <Card
                            className={styles.controlsCard}
                            style={{
                                borderRadius: tokens.borderRadiusMedium,
                                padding: tokens.spacingHorizontalM
                            }}
                        >
                            <CardHeader header={<Text weight="semibold" size={500}>Theme Designer</Text>} />
                            <Field label="Preset Colors">
                                <Dropdown
                                    placeholder="Select a preset color"
                                    value={selectedPresetColorName || ''}
                                    selectedOptions={selectedPresetColorName ? [selectedPresetColorName] : []}
                                    onOptionSelect={(_, data) => {
                                        const selected = presetColors.find(pc => pc.name === data.optionValue);
                                        if (selected) {
                                            setBrandColor(selected.color);
                                            setBaseColorInput(selected.color);
                                            setSelectedPresetColorName(selected.name);
                                        }
                                    }}
                                >
                                    {presetColors.map(pc => (
                                        <Option key={pc.name} value={pc.name}>
                                            <span className={styles.swatchBox} style={{ backgroundColor: pc.color }}></span>
                                            {pc.name}
                                        </Option>
                                    ))}
                                </Dropdown>
                            </Field>
                            <Field label="Brand Color">
                                <input
                                    type="color"
                                    value={brandColor}
                                    onChange={(e) => setBrandColor(e.target.value)}
                                    className={styles.colorInput}
                                    aria-label="Brand color picker"
                                />
                            </Field>
                            <Field label="Base Color (Hex)">
                                <Input
                                    value={baseColorInput}
                                    onChange={(_, data) => setBaseColorInput(data.value)}
                                    onBlur={handleBaseColorBlur}
                                    placeholder="Enter a hex color"
                                />
                            </Field>
                            <Field label="Font Family">
                                <Dropdown
                                    placeholder="Select a font"
                                    value={selectedFont}
                                    selectedOptions={[selectedFont]}
                                    onOptionSelect={(_, data) => {
                                        if (data.optionValue) {
                                            setSelectedFont(data.optionValue);
                                        }
                                    }}
                                >
                                    {fonts.map(font => (
                                        <Option key={font} value={font}>
                                            {font}
                                        </Option>
                                    ))}
                                </Dropdown>
                            </Field>
                            <Field label="Hue Torsion:">
                                <div className={styles.sliderContainer}>
                                    <Slider
                                        value={hueTorsion}
                                        min={-50}
                                        max={50}
                                        step={1}
                                        onChange={(_, data) => setHueTorsion(data.value)}
                                    />
                                    <Input
                                        size="small"
                                        type="number"
                                        min={-50}
                                        max={50}
                                        appearance="outline"
                                        value={hueTorsion.toString()}
                                        onChange={(_, data) => setHueTorsion(Number(data.value))}
                                    />
                                </div>
                            </Field>
                            <Field label="Vibrancy:">
                                <div className={styles.sliderContainer}>
                                    <Slider
                                        value={vibrancy}
                                        min={-50}
                                        max={50}
                                        step={1}
                                        onChange={(_, data) => setVibrancy(data.value)}
                                    />
                                    <Input
                                        size="small"
                                        type="number"
                                        min={-50}
                                        max={50}
                                        appearance="outline"
                                        value={vibrancy.toString()}
                                        onChange={(_, data) => setVibrancy(Number(data.value))}
                                    />
                                </div>
                            </Field>
                            <Field>
                                <Switch
                                    checked={lockPrimary}
                                    onChange={(_, data) => setLockPrimary(data.checked)}
                                    label="Lock Primary"
                                />
                            </Field>
                            <CardFooter>
                                <Button appearance="primary" icon={<SaveRegular />} onClick={handleSaveTheme}>
                                    Save Theme
                                </Button>
                            </CardFooter>
                            <Field label="Theme XML" className={styles.xmlFieldContainer}>
                                <Textarea
                                    value={`<CustomTheme basePaletteColor="${debouncedBrandColor}" vibrancy="${debouncedVibrancy}" hueTorsion="${debouncedHueTorsion}" lockPrimary="${debouncedLockPrimary}" font="${debouncedFont}" />`}
                                    readOnly
                                    className={styles.xmlTextarea}
                                />
                            </Field>
                        </Card>
                    </FluentProvider>

                    <FluentProvider theme={previewTheme} style={{ flex: 1 }}>
                        <Card className={styles.previewCard}>
                            <CardHeader header={<Text size={500} weight="semibold">Theme Preview</Text>} />
                            <div className={styles.paletteContainer}>
                                {paletteKeys.map((key) => (
                                    <div
                                        key={key}
                                        className={styles.paletteBox}
                                        style={{ backgroundColor: previewBrandVariants[key as keyof BrandVariants] }}
                                    >
                                        {key}
                                    </div>
                                ))}
                            </div>

                            <div className={styles.previewBox}>
                                <div className={styles.previewGrid}>
                                    <div className={styles.section}>
                                        <div className={styles.personaSection}>
                                            <Persona
                                                name="Cameron Evans"
                                                secondaryText="Senior Researcher at Contoso"
                                                avatar={{ color: 'brand' }}
                                            />
                                        </div>
                                        <TabList defaultSelectedValue="home" className={styles.tabsRow}>
                                            <Tab value="home">Home</Tab>
                                            <Tab value="pages">Pages</Tab>
                                            <Tab value="documents">Documents</Tab>
                                        </TabList>
                                        <Input appearance="filled-darker" placeholder="Find" contentAfter={<SearchRegular />} />
                                        <Dropdown placeholder="Select" appearance="filled-darker">
                                            <Option>Option 1</Option>
                                            <Option>Option 2</Option>
                                            <Option>Option 3</Option>
                                        </Dropdown>
                                    </div>

                                    <div className={styles.section}>
                                        <Button appearance="primary">Text</Button>
                                        <div className={styles.switchesRow}>
                                            <Switch checked label="On" />
                                            <Switch checked={false} label="Off" />
                                        </div>
                                        <div>
                                            <Slider defaultValue={50} />
                                        </div>
                                        <div>
                                            <Checkbox label="Option 1" defaultChecked />
                                            <Checkbox label="Option 2" />
                                        </div>
                                    </div>

                                    <div className={styles.section}>
                                        <Field label={<><Text>Description</Text><Text className={styles.requiredMark}>*</Text></>}>
                                            <Input placeholder="Example Text" appearance="filled-darker" />
                                        </Field>
                                        <RadioGroup defaultValue="option1">
                                            <Radio value="option1" label="Option 1" />
                                            <Radio value="option2" label="Option 2" />
                                        </RadioGroup>
                                        <Link href="https://www.microsoft.com" target="_blank">
                                            Example link - www.microsoft.com
                                        </Link>
                                    </div>
                                </div>

                                <div>
                                    <Card>
                                        <CardHeader header={<Text size={500} weight="semibold">User Data Grid</Text>} />
                                        <DataGrid items={gridItems} columns={columns} getRowId={(item) => item.id} selectionMode="multiselect">
                                            <DataGridHeader>
                                                <DataGridRow>
                                                    {({ renderHeaderCell }) => (
                                                        <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                                                    )}
                                                </DataGridRow>
                                            </DataGridHeader>
                                            <DataGridBody>
                                                {({ item }) => (
                                                    <DataGridRow key={item.id}>
                                                        {({ renderCell }) => (
                                                            <DataGridCell>{renderCell(item)}</DataGridCell>
                                                        )}
                                                    </DataGridRow>
                                                )}
                                            </DataGridBody>
                                        </DataGrid>
                                    </Card>
                                </div>
                            </div>
                        </Card>
                    </FluentProvider>
                </div>
            </div>
        </FluentProvider>
    );
};

export default GeneratedComponent;
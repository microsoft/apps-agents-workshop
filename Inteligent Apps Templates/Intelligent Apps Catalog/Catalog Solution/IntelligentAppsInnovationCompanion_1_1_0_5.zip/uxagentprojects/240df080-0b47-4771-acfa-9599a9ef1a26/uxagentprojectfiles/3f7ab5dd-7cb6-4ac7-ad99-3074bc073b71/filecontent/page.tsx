import React, { useEffect, useState } from "react";
import {
    Button,
    Text,
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn,
    Badge,
    makeStyles,
    tokens,
    Spinner,
    Input,
    Textarea,
    Combobox,
    Option
} from "@fluentui/react-components";
import { ChevronDownRegular, ChevronUpRegular, EditRegular, DismissRegular, SaveRegular } from "@fluentui/react-icons";
import { DatePicker } from "@fluentui/react-datepicker-compat";
import type {
    GeneratedComponentProps,
    cat_project,
    cat_task,
    ReadableTableRow,
    WritableTableRow,
    QueryTableOptions,
    EnumChoice
} from "./RuntimeTypes";

const useStyles = makeStyles({
    container: {
        display: "flex",
        flexDirection: "column",
        gap: tokens.spacingVerticalL,
        padding: tokens.spacingHorizontalM,
        width: "100%",
        boxSizing: "border-box",
        position: "relative"
    },
    projectCard: {
        border: `1px solid ${tokens.colorNeutralStroke1}`,
        borderRadius: tokens.borderRadiusMedium,
        backgroundColor: tokens.colorNeutralBackground1,
        boxShadow: tokens.shadow4,
    },
    projectHeader: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: tokens.spacingHorizontalM,
        cursor: "pointer",
        userSelect: "none",
    },
    taskTableWrapper: {
        padding: tokens.spacingHorizontalM,
        paddingTop: 0,
    },
    editPanel: {
        position: "fixed",
        top: 0,
        right: 0,
        height: "100%",
        width: "100%",
        maxWidth: "400px",
        backgroundColor: tokens.colorNeutralBackground1,
        boxShadow: tokens.shadow28,
        display: "flex",
        flexDirection: "column",
        transform: "translateX(100%)",
        transition: "transform 0.3s ease-in-out",
        zIndex: 1000,
    },
    editPanelOpen: {
        transform: "translateX(0)",
    },
    panelHeader: {
        background: "linear-gradient(90deg, #0078D4, #00B7C3)",
        color: "#fff",
        padding: tokens.spacingHorizontalM,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
    },
    panelBody: {
        padding: tokens.spacingHorizontalM,
        overflowY: "auto",
        flex: 1,
        display: "flex",
        flexDirection: "column",
        gap: tokens.spacingVerticalM,
    },
    panelFooter: {
        padding: tokens.spacingHorizontalM,
        display: "flex",
        justifyContent: "flex-end",
        gap: tokens.spacingHorizontalS,
        borderTop: `1px solid ${tokens.colorNeutralStroke2}`,
    }
});

const getStatusColor = (statusLabel: string): "brand" | "important" | "informative" | "severe" | "success" => {
    switch (statusLabel) {
        case "In Progress": return "brand";
        case "Completed": return "success";
        case "Blocked": return "important";
        case "Not Started": return "informative";
        default: return "brand";
    }
};

const getPriorityColor = (priorityLabel: string): "brand" | "important" | "informative" | "severe" | "success" => {
    switch (priorityLabel) {
        case "Urgent": return "important";
        case "High": return "severe";
        case "Medium": return "brand";
        case "Low": return "informative";
        default: return "brand";
    }
};

const TaskTable = ({ tasks, onEdit }: { tasks: ReadableTableRow<cat_task>[]; onEdit: (task: ReadableTableRow<cat_task>) => void }) => {
    const columns = [
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskname",
            renderHeaderCell: () => "Task name",
            renderCell: (item) => <TableCellLayout>{item.cat_taskname}</TableCellLayout>,
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskstatus",
            renderHeaderCell: () => "Status",
            renderCell: (item) => (
                <Badge appearance="filled" color={getStatusColor(item["cat_taskstatus@OData.Community.Display.V1.FormattedValue"] || "")}>
                    {item["cat_taskstatus@OData.Community.Display.V1.FormattedValue"] || ""}
                </Badge>
            ),
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_priority",
            renderHeaderCell: () => "Priority",
            renderCell: (item) => (
                <Badge appearance="filled" color={getPriorityColor(item["cat_priority@OData.Community.Display.V1.FormattedValue"] || "")}>
                    {item["cat_priority@OData.Community.Display.V1.FormattedValue"] || ""}
                </Badge>
            ),
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_deadline",
            renderHeaderCell: () => "Deadline",
            renderCell: (item) => new Date(item.cat_deadline).toLocaleDateString(),
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "_cat_assignedto_value",
            renderHeaderCell: () => "Assigned to",
            renderCell: (item) => item["_cat_assignedto_value@OData.Community.Display.V1.FormattedValue"] || "",
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_estimatedhours",
            renderHeaderCell: () => "Estimated hours",
            renderCell: (item) => item.cat_estimatedhours?.toString() || "",
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "actions",
            renderHeaderCell: () => "Actions",
            renderCell: (item) => (
                <Button appearance="subtle" icon={<EditRegular />} aria-label="Edit task" onClick={() => onEdit(item)} />
            ),
        }),
    ];

    return (
        <DataGrid items={tasks} columns={columns} focusMode="composite" style={{ marginTop: tokens.spacingVerticalS }}>
            <DataGridHeader>
                <DataGridRow>
                    {({ renderHeaderCell }) => (
                        <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                    )}
                </DataGridRow>
            </DataGridHeader>
            <DataGridBody>
                {({ item }) => (
                    <DataGridRow key={item.cat_taskid}>
                        {({ renderCell }) => <DataGridCell>{renderCell(item)}</DataGridCell>}
                    </DataGridRow>
                )}
            </DataGridBody>
        </DataGrid>
    );
};

const GeneratedComponent = ({ dataApi }: GeneratedComponentProps) => {
    const styles = useStyles();
    const [projects, setProjects] = useState<ReadableTableRow<cat_project>[]>([]);
    const [expandedProjects, setExpandedProjects] = useState<Record<string, boolean>>({});
    const [tasksByProject, setTasksByProject] = useState<Record<string, ReadableTableRow<cat_task>[]>>({});
    const [loadingTasks, setLoadingTasks] = useState<Record<string, boolean>>({});
    const [isPanelOpen, setIsPanelOpen] = useState(false);
    const [selectedTask, setSelectedTask] = useState<ReadableTableRow<cat_task> | null>(null);
    const [editFormData, setEditFormData] = useState<WritableTableRow<cat_task>>({
        cat_taskname: "",
        cat_description: "",
        cat_deadline: new Date(),
        cat_estimatedhours: 0,
        cat_priority: 687440000,
        cat_taskstatus: 687440000
    });
    const [priorityChoices, setPriorityChoices] = useState<EnumChoice<"cat_task-cat_priority", any>[]>([]);
    const [statusChoices, setStatusChoices] = useState<EnumChoice<"cat_task-cat_taskstatus", any>[]>([]);

    useEffect(() => {
        const loadProjects = async () => {
            const query: QueryTableOptions<cat_project> = {
                select: ["cat_projectid", "cat_projectname"],
                orderBy: "cat_projectname asc"
            };
            const result = await dataApi.queryTable("cat_project", query);
            setProjects(result.rows);
        };
        loadProjects();

        const loadChoices = async () => {
            const priorities = await dataApi.getChoices("cat_task-cat_priority");
            const statuses = await dataApi.getChoices("cat_task-cat_taskstatus");
            setPriorityChoices(priorities);
            setStatusChoices(statuses);
        };
        loadChoices();
    }, [dataApi]);

    const toggleProject = async (projectId: string) => {
        const isExpanded = expandedProjects[projectId];
        const newExpanded = { ...expandedProjects, [projectId]: !isExpanded };
        setExpandedProjects(newExpanded);

        if (!isExpanded && !tasksByProject[projectId]) {
            setLoadingTasks(prev => ({ ...prev, [projectId]: true }));
            const query: QueryTableOptions<cat_task> = {
                select: [
                    "cat_taskid",
                    "cat_taskname",
                    "cat_taskstatus",
                    "cat_priority",
                    "cat_deadline",
                    "_cat_assignedto_value",
                    "cat_estimatedhours",
                    "cat_description"
                ],
                filter: `_cat_project_value eq '/cat_project(${projectId})'`
            };
            const result = await dataApi.queryTable("cat_task", query);
            setTasksByProject(prev => ({ ...prev, [projectId]: result.rows }));
            setLoadingTasks(prev => ({ ...prev, [projectId]: false }));
        }
    };

    const handleEditClick = (task: ReadableTableRow<cat_task>) => {
        setSelectedTask(task);
        setEditFormData({
            cat_taskname: task.cat_taskname || "",
            cat_description: task.cat_description || "",
            cat_deadline: task.cat_deadline ? new Date(task.cat_deadline) : new Date(),
            cat_estimatedhours: task.cat_estimatedhours || 0,
            cat_priority: task.cat_priority,
            cat_taskstatus: task.cat_taskstatus
        });
        setIsPanelOpen(true);
    };

    const handleSave = async () => {
        if (selectedTask) {
            await dataApi.updateRow("cat_task", selectedTask.cat_taskid, editFormData);
            // Update local state
            const projectId = selectedTask._cat_project_value.match(/\(([^)]+)\)/)?.[1];
            if (projectId) {
                const updatedTasks = (tasksByProject[projectId] || []).map(t =>
                    t.cat_taskid === selectedTask.cat_taskid ? { ...t, ...editFormData } : t
                );
                setTasksByProject(prev => ({ ...prev, [projectId]: updatedTasks }));
            }
            setIsPanelOpen(false);
            setSelectedTask(null);
        }
    };

    return (
        <div className={styles.container}>
            {projects.map(proj => (
                <div key={proj.cat_projectid} className={styles.projectCard}>
                    <div className={styles.projectHeader} onClick={() => toggleProject(proj.cat_projectid)} role="button" aria-expanded={!!expandedProjects[proj.cat_projectid]}>
                        <Text weight="semibold" size={400}>{proj.cat_projectname}</Text>
                        {expandedProjects[proj.cat_projectid] ? <ChevronUpRegular /> : <ChevronDownRegular />}
                    </div>
                    {expandedProjects[proj.cat_projectid] && (
                        <div className={styles.taskTableWrapper}>
                            {loadingTasks[proj.cat_projectid] ? (
                                <Spinner label="Loading tasks..." />
                            ) : (
                                <TaskTable tasks={tasksByProject[proj.cat_projectid] || []} onEdit={handleEditClick} />
                            )}
                        </div>
                    )}
                </div>
            ))}

            {/* Slide-in Edit Panel */}
            <div className={`${styles.editPanel} ${isPanelOpen ? styles.editPanelOpen : ""}`} role="dialog" aria-modal="true">
                {selectedTask && (
                    <>
                        <div className={styles.panelHeader}>
                            <Text weight="semibold" size={500}>{selectedTask.cat_taskname}</Text>
                            <Button appearance="transparent" icon={<DismissRegular />} onClick={() => setIsPanelOpen(false)} />
                        </div>
                        <div className={styles.panelBody}>
                            <Input label="Task Name" value={editFormData.cat_taskname} onChange={(e, d) => setEditFormData(prev => ({ ...prev, cat_taskname: d.value }))} />
                            <Textarea label="Description" value={editFormData.cat_description} onChange={(e, d) => setEditFormData(prev => ({ ...prev, cat_description: d.value }))} />
                            <DatePicker
                                placeholder="Select deadline"
                                value={editFormData.cat_deadline}
                                onSelectDate={(date) => setEditFormData(prev => ({ ...prev, cat_deadline: date || new Date() }))}
                            />
                            <Input type="number" label="Estimated Hours" value={editFormData.cat_estimatedhours.toString()} onChange={(e, d) => setEditFormData(prev => ({ ...prev, cat_estimatedhours: Number(d.value) }))} />
                            <Combobox value={priorityChoices.find(c => c.value === editFormData.cat_priority)?.label || ""} onOptionSelect={(e, d) => {
                                const choice = priorityChoices.find(c => c.label === d.optionText);
                                if (choice) setEditFormData(prev => ({ ...prev, cat_priority: choice.value }));
                            }} placeholder="Select Priority">
                                {priorityChoices.map(c => <Option key={c.value} value={c.label}>{c.label}</Option>)}
                            </Combobox>
                            <Combobox value={statusChoices.find(c => c.value === editFormData.cat_taskstatus)?.label || ""} onOptionSelect={(e, d) => {
                                const choice = statusChoices.find(c => c.label === d.optionText);
                                if (choice) setEditFormData(prev => ({ ...prev, cat_taskstatus: choice.value }));
                            }} placeholder="Select Status">
                                {statusChoices.map(c => <Option key={c.value} value={c.label}>{c.label}</Option>)}
                            </Combobox>
                        </div>
                        <div className={styles.panelFooter}>
                            <Button appearance="secondary" onClick={() => setIsPanelOpen(false)}>Cancel</Button>
                            <Button appearance="primary" icon={<SaveRegular />} onClick={handleSave}>Save</Button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default GeneratedComponent;
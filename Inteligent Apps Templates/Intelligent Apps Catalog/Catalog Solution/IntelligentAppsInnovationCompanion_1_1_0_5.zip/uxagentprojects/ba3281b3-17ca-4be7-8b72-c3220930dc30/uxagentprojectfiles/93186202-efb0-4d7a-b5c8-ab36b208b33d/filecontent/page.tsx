import React, { useEffect, useState } from 'react';
import {
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn,
    Text,
    Button
} from '@fluentui/react-components';
import type { GeneratedComponentProps, ReadableTableRow, QueryTableOptions, cat_project, cat_task } from "./RuntimeTypes";

const GeneratedComponent: React.FC<GeneratedComponentProps> = ({ dataApi }) => {
    const [projects, setProjects] = useState<ReadableTableRow<cat_project>[]>([]);
    const [expandedProjectId, setExpandedProjectId] = useState<string | null>(null);
    const [tasks, setTasks] = useState<Record<string, ReadableTableRow<cat_task>[]>>({});
    const [loadingProjects, setLoadingProjects] = useState(false);
    const [loadingTasks, setLoadingTasks] = useState<string | null>(null);

    const fetchProjects = async () => {
        setLoadingProjects(true);
        const query: QueryTableOptions<cat_project> = {
            select: ["cat_projectid", "cat_projectname", "cat_startdate", "cat_enddate", "cat_projectbudget", "statecode", "statuscode"],
            orderBy: "cat_projectname asc",
            pageSize: 50
        };
        const result = await dataApi.queryTable("cat_project", query);
        setProjects(result.rows);
        setLoadingProjects(false);
    };

    const fetchTasksForProject = async (projectId: string) => {
        setLoadingTasks(projectId);
        const query: QueryTableOptions<cat_task> = {
            select: ["cat_taskid", "cat_taskname", "cat_deadline", "cat_priority", "cat_taskstatus", "_cat_project_value"],
            filter: `_cat_project_value eq '/cat_project(${projectId})'`,
            orderBy: "cat_taskname asc"
        };
        const result = await dataApi.queryTable("cat_task", query);
        setTasks(prev => ({ ...prev, [projectId]: result.rows }));
        setLoadingTasks(null);
    };

    useEffect(() => {
        fetchProjects();
    }, []);

    const projectColumns = [
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_projectname",
            renderHeaderCell: () => "Project Name",
            renderCell: (item) => <TableCellLayout>{item.cat_projectname}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_startdate",
            renderHeaderCell: () => "Start Date",
            renderCell: (item) => <TableCellLayout>{item.cat_startdate ? new Date(item.cat_startdate).toLocaleDateString() : ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_enddate",
            renderHeaderCell: () => "End Date",
            renderCell: (item) => <TableCellLayout>{item.cat_enddate ? new Date(item.cat_enddate).toLocaleDateString() : ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_projectbudget",
            renderHeaderCell: () => "Budget",
            renderCell: (item) => <TableCellLayout>${item.cat_projectbudget?.toLocaleString()}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "statuscode",
            renderHeaderCell: () => "Status",
            renderCell: (item) => <TableCellLayout>{item["statuscode@OData.Community.Display.V1.FormattedValue"] || ""}</TableCellLayout>
        })
    ];

    const taskColumns = [
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskname",
            renderHeaderCell: () => "Task Name",
            renderCell: (item) => <TableCellLayout>{item.cat_taskname}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_deadline",
            renderHeaderCell: () => "Deadline",
            renderCell: (item) => <TableCellLayout>{item.cat_deadline ? new Date(item.cat_deadline).toLocaleDateString() : ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_priority",
            renderHeaderCell: () => "Priority",
            renderCell: (item) => <TableCellLayout>{item["cat_priority@OData.Community.Display.V1.FormattedValue"] || ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskstatus",
            renderHeaderCell: () => "Status",
            renderCell: (item) => <TableCellLayout>{item["cat_taskstatus@OData.Community.Display.V1.FormattedValue"] || ""}</TableCellLayout>
        })
    ];

    const handleExpand = (projectId: string) => {
        if (expandedProjectId === projectId) {
            setExpandedProjectId(null);
        } else {
            setExpandedProjectId(projectId);
            if (!tasks[projectId]) {
                fetchTasksForProject(projectId);
            }
        }
    };

    return (
        <div style={{ display: "flex", flexDirection: "column", width: "100%", height: "100%", padding: "16px", boxSizing: "border-box" }}>
            <Text size={600} weight="semibold" block style={{ marginBottom: "12px" }}>Projects and Related Tasks</Text>
            <Button appearance="primary" onClick={fetchProjects} style={{ marginBottom: "12px", alignSelf: "flex-start" }}>
                Refresh Projects
            </Button>
            <div style={{ flex: 1, overflow: "auto" }}>
                <DataGrid
                    items={projects}
                    columns={projectColumns}
                    getRowId={(item) => item.cat_projectid}
                    focusMode="composite"
                    style={{ width: "100%" }}
                >
                    <DataGridHeader>
                        <DataGridRow>
                            {({ renderHeaderCell }) => (
                                <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                            )}
                        </DataGridRow>
                    </DataGridHeader>
                    <DataGridBody<ReadableTableRow<cat_project>>>
                        {({ item }) => (
                            <>
                                <DataGridRow key={item.cat_projectid} onClick={() => handleExpand(item.cat_projectid)} style={{ cursor: "pointer" }}>
                                    {({ renderCell }) => (
                                        <DataGridCell>{renderCell(item)}</DataGridCell>
                                    )}
                                </DataGridRow>
                                {expandedProjectId === item.cat_projectid && (
                                    <tr>
                                        <td colSpan={projectColumns.length} style={{ padding: "8px 16px", backgroundColor: "#f9f9f9" }}>
                                            <Text weight="semibold" block style={{ marginBottom: "8px" }}>Tasks</Text>
                                            {loadingTasks === item.cat_projectid ? (
                                                <Text>Loading tasks...</Text>
                                            ) : (
                                                <DataGrid
                                                    items={tasks[item.cat_projectid] || []}
                                                    columns={taskColumns}
                                                    getRowId={(task) => task.cat_taskid}
                                                    focusMode="composite"
                                                    style={{ width: "100%" }}
                                                >
                                                    <DataGridHeader>
                                                        <DataGridRow>
                                                            {({ renderHeaderCell }) => (
                                                                <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                                                            )}
                                                        </DataGridRow>
                                                    </DataGridHeader>
                                                    <DataGridBody<ReadableTableRow<cat_task>>>
                                                        {({ item: task }) => (
                                                            <DataGridRow key={task.cat_taskid}>
                                                                {({ renderCell }) => (
                                                                    <DataGridCell>{renderCell(task)}</DataGridCell>
                                                                )}
                                                            </DataGridRow>
                                                        )}
                                                    </DataGridBody>
                                                </DataGrid>
                                            )}
                                        </td>
                                    </tr>
                                )}
                            </>
                        )}
                    </DataGridBody>
                </DataGrid>
            </div>
        </div>
    );
};

export default GeneratedComponent;
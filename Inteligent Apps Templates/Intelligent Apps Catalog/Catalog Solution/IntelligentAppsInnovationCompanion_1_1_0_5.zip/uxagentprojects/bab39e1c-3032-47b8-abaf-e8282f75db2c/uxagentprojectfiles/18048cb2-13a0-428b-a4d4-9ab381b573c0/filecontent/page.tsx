import React, { useEffect, useState, useMemo } from "react";
import {
    Text,
    Spinner,
    Dialog,
    DialogSurface,
    DialogBody,
    DialogTitle,
    DialogActions,
    Button,
    Tooltip,
    useId,
} from "@fluentui/react-components";
import { InfoRegular } from "@fluentui/react-icons";
import * as d3 from "d3";
import type {
    GeneratedComponentProps,
    cat_project,
    cat_task,
    systemuser,
    ReadableTableRow,
    QueryTableOptions,
} from "./RuntimeTypes";

// --- Utility: Format date as YYYY-MM-DD
function formatDate(date: Date | string | undefined): string {
    if (!date) return "";
    const d = typeof date === "string" ? new Date(date) : date;
    return d.toISOString().slice(0, 10);
}

// --- Utility: Get month index (0=Jan, 11=Dec)
function getMonthIdx(date: Date | string): number {
    const d = typeof date === "string" ? new Date(date) : date;
    return d.getMonth();
}

// --- Utility: Clamp date to current year
function clampToYear(date: Date, year: number): Date {
    if (date.getFullYear() < year) return new Date(year, 0, 1);
    if (date.getFullYear() > year) return new Date(year, 11, 31);
    return date;
}

// --- Gantt Data Model
interface GanttTaskBar {
    id: string;
    projectName: string;
    taskName: string;
    assignedUser: string;
    start: Date;
    end: Date;
    color: string;
    task: ReadableTableRow<cat_task>;
    project: ReadableTableRow<cat_project>;
    user: ReadableTableRow<systemuser> | undefined;
}

// --- Main Component
const GeneratedComponent = ({ dataApi }: GeneratedComponentProps) => {
    // State
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [projects, setProjects] = useState<ReadableTableRow<cat_project>[]>([]);
    const [tasks, setTasks] = useState<ReadableTableRow<cat_task>[]>([]);
    const [users, setUsers] = useState<ReadableTableRow<systemuser>[]>([]);
    const [selectedTask, setSelectedTask] = useState<GanttTaskBar | null>(null);

    // Fetch data on mount
    useEffect(() => {
        let mounted = true;
        async function fetchAll() {
            setLoading(true);
            setError(null);
            try {
                // 1. Fetch all projects (get id, name, start/end, owner)
                const projectQuery: QueryTableOptions<cat_project> = {
                    select: [
                        "cat_projectid",
                        "cat_projectname",
                        "cat_startdate",
                        "cat_enddate",
                        "_cat_projectowner_value",
                    ],
                    pageSize: 100,
                    orderBy: "cat_startdate asc",
                };
                const projectResult = await dataApi.queryTable("cat_project", projectQuery);

                // 2. Fetch all tasks (get id, name, deadline, project, assigned user, status)
                const taskQuery: QueryTableOptions<cat_task> = {
                    select: [
                        "cat_taskid",
                        "cat_taskname",
                        "cat_deadline",
                        "_cat_project_value",
                        "_cat_assignedto_value",
                        "cat_taskstatus",
                        "cat_priority",
                    ],
                    pageSize: 200,
                    orderBy: "cat_deadline asc",
                };
                const taskResult = await dataApi.queryTable("cat_task", taskQuery);

                // 3. Fetch all users (id, fullname, firstname, lastname)
                const userQuery: QueryTableOptions<systemuser> = {
                    select: [
                        "systemuserid",
                        "fullname",
                        "firstname",
                        "lastname",
                    ],
                    pageSize: 100,
                    orderBy: "fullname asc",
                };
                const userResult = await dataApi.queryTable("systemuser", userQuery);

                if (!mounted) return;
                setProjects(projectResult.rows);
                setTasks(taskResult.rows);
                setUsers(userResult.rows);
                setLoading(false);
            } catch (e: any) {
                setError("Failed to load data. " + (e?.message || ""));
                setLoading(false);
            }
        }
        fetchAll();
        return () => { mounted = false; };
    }, [dataApi]);

    // --- Prepare Gantt Data
    const currentYear = new Date().getFullYear();
    const ganttData: GanttTaskBar[] = useMemo(() => {
        // Map for quick lookup
        const projectMap = new Map<string, ReadableTableRow<cat_project>>();
        projects.forEach(p => projectMap.set(p.cat_projectid, p));
        const userMap = new Map<string, ReadableTableRow<systemuser>>();
        users.forEach(u => userMap.set(u.systemuserid, u));

        // Assign a color per project (cycling through a palette)
        const colorPalette = [
            "#0078D4", "#E81123", "#107C10", "#FFB900", "#B4009E", "#00B7C3", "#D83B01", "#5C2D91", "#498205", "#C239B3"
        ];
        const projectColorMap = new Map<string, string>();
        projects.forEach((p, idx) => {
            projectColorMap.set(p.cat_projectid, colorPalette[idx % colorPalette.length]);
        });

        // Build Gantt bars
        return tasks.map(task => {
            const projectId = task._cat_project_value?.match(/\(([^)]+)\)/)?.[1] || "";
            const project = projectMap.get(projectId);
            // Use project start as task start (since task has only deadline)
            const start = project?.cat_startdate ? new Date(project.cat_startdate) : new Date(currentYear, 0, 1);
            const end = task.cat_deadline ? new Date(task.cat_deadline) : start;
            // Clamp to current year for display
            const clampedStart = clampToYear(start, currentYear);
            const clampedEnd = clampToYear(end, currentYear);
            // Assigned user
            const userId = task._cat_assignedto_value?.match(/\(([^)]+)\)/)?.[1] || "";
            const user = userMap.get(userId);
            return {
                id: task.cat_taskid,
                projectName: project?.cat_projectname || "Unknown Project",
                taskName: task.cat_taskname || "Untitled Task",
                assignedUser: user?.fullname || "Unassigned",
                start: clampedStart,
                end: clampedEnd,
                color: projectColorMap.get(projectId) || "#888",
                task,
                project: project || {} as any,
                user,
            };
        }).sort((a, b) => a.start.getTime() - b.start.getTime());
    }, [tasks, projects, users, currentYear]);

    // --- Gantt Chart Layout Constants
    const chartPadding = { top: 40, left: 180, right: 40, bottom: 20 };
    const rowHeight = 36;
    const barHeight = 18;
    const monthLabels = d3.timeMonths(new Date(currentYear, 0, 1), new Date(currentYear + 1, 0, 1));
    const chartHeight = ganttData.length * rowHeight + chartPadding.top + chartPadding.bottom;
    const chartWidth = 1200; // Fixed width for 12 months, will scroll horizontally if container is smaller

    // --- Gantt Chart Rendering
    function renderGanttChart() {
        // X scale: months (Jan–Dec)
        const xScale = d3.scaleTime()
            .domain([new Date(currentYear, 0, 1), new Date(currentYear, 11, 31)])
            .range([chartPadding.left, chartWidth - chartPadding.right]);

        // Y scale: task rows
        const yScale = (idx: number) => chartPadding.top + idx * rowHeight;

        // For accessibility, use aria-labels and focusable bars
        return (
            <svg
                width="100%"
                height={chartHeight}
                viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                style={{ minWidth: 700, maxWidth: "100%", display: "block", background: "#fff", borderRadius: 8, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}
                aria-label="Gantt chart"
                tabIndex={0}
            >
                {/* Month grid lines and labels */}
                {monthLabels.map((d, i) => {
                    const x = xScale(d);
                    return (
                        <g key={i}>
                            <line
                                x1={x}
                                y1={chartPadding.top - 8}
                                x2={x}
                                y2={chartHeight - chartPadding.bottom}
                                stroke="#E1DFDD"
                                strokeWidth={1}
                            />
                            <Text
                                as="text"
                                size={300}
                                style={{
                                    fontWeight: 600,
                                    fill: "#333",
                                    fontSize: 14,
                                    pointerEvents: "none",
                                }}
                                x={x + 4}
                                y={chartPadding.top - 16}
                            >
                                {d3.timeFormat("%b")(d)}
                            </Text>
                        </g>
                    );
                })}
                {/* Row labels (project/task/user) */}
                {ganttData.map((bar, idx) => (
                    <g key={bar.id}>
                        <text
                            x={chartPadding.left - 10}
                            y={yScale(idx) + barHeight + 2}
                            textAnchor="end"
                            fontSize={13}
                            fill="#444"
                            style={{ fontFamily: "inherit", pointerEvents: "none" }}
                        >
                            {bar.projectName}
                        </text>
                        <text
                            x={chartPadding.left - 10}
                            y={yScale(idx) + barHeight + 18}
                            textAnchor="end"
                            fontSize={12}
                            fill="#888"
                            style={{ fontFamily: "inherit", pointerEvents: "none" }}
                        >
                            {bar.taskName}
                        </text>
                        <text
                            x={chartPadding.left - 10}
                            y={yScale(idx) + barHeight + 32}
                            textAnchor="end"
                            fontSize={11}
                            fill="#0078D4"
                            style={{ fontFamily: "inherit", pointerEvents: "none" }}
                        >
                            {bar.assignedUser}
                        </text>
                    </g>
                ))}
                {/* Task bars */}
                {ganttData.map((bar, idx) => {
                    const x1 = xScale(bar.start);
                    const x2 = xScale(bar.end);
                    const y = yScale(idx);
                    const barId = `gantt-bar-${bar.id}`;
                    return (
                        <Tooltip
                            key={bar.id}
                            content={
                                <div style={{ minWidth: 220 }}>
                                    <Text size={400} weight="semibold" block>{bar.taskName}</Text>
                                    <Text size={300} block>Project: {bar.projectName}</Text>
                                    <Text size={300} block>Assigned: {bar.assignedUser}</Text>
                                    <Text size={300} block>
                                        {formatDate(bar.start)} – {formatDate(bar.end)}
                                    </Text>
                                </div>
                            }
                            relationship="label"
                        >
                            <rect
                                id={barId}
                                x={x1}
                                y={y + (rowHeight - barHeight) / 2}
                                width={Math.max(8, x2 - x1)}
                                height={barHeight}
                                rx={6}
                                fill={bar.color}
                                style={{
                                    cursor: "pointer",
                                    filter: selectedTask?.id === bar.id ? "brightness(1.2)" : "none",
                                    transition: "filter 0.2s",
                                }}
                                tabIndex={0}
                                aria-label={`Task ${bar.taskName}, project ${bar.projectName}, assigned to ${bar.assignedUser}, from ${formatDate(bar.start)} to ${formatDate(bar.end)}`}
                                onClick={() => setSelectedTask(bar)}
                                onKeyDown={e => {
                                    if (e.key === "Enter" || e.key === " ") setSelectedTask(bar);
                                }}
                            />
                        </Tooltip>
                    );
                })}
                {/* Row separators */}
                {ganttData.map((_, idx) => (
                    <line
                        key={`sep-${idx}`}
                        x1={chartPadding.left}
                        y1={yScale(idx + 1) - rowHeight / 2}
                        x2={chartWidth - chartPadding.right}
                        y2={yScale(idx + 1) - rowHeight / 2}
                        stroke="#F3F2F1"
                        strokeWidth={1}
                    />
                ))}
            </svg>
        );
    }

    // --- Main Render
    return (
        <div style={{
            flexGrow: 1,
            alignSelf: "stretch",
            width: "100%",
            height: "100%",
            minHeight: 0,
            minWidth: 0,
            display: "flex",
            flexDirection: "column",
            boxSizing: "border-box",
            padding: 24,
            background: "#FAFAFA",
            overflow: "hidden"
        }}>
            {/* Page Header */}
            <header style={{ marginBottom: 16, display: "flex", alignItems: "center", gap: 12 }}>
                <InfoRegular fontSize="28px" style={{ color: "#0078D4" }} />
                <Text as="h1" size={700} weight="semibold" block>
                    Project Task Gantt Chart
                </Text>
            </header>
            {/* Chart Section */}
            <section style={{
                flex: 1,
                minHeight: 0,
                background: "#fff",
                borderRadius: "8px",
                boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
                padding: 0,
                display: "flex",
                flexDirection: "column",
                overflow: "hidden"
            }}>
                {loading ? (
                    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Spinner size="large" label="Loading Gantt chart..." />
                    </div>
                ) : error ? (
                    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Text as="p" size={400} style={{ color: "#E81123" }}>{error}</Text>
                    </div>
                ) : ganttData.length === 0 ? (
                    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Text as="p" size={400}>No tasks found for this year.</Text>
                    </div>
                ) : (
                    <div style={{
                        flex: 1,
                        minHeight: 0,
                        overflow: "auto",
                        padding: 0,
                        boxSizing: "border-box"
                    }}>
                        {renderGanttChart()}
                    </div>
                )}
            </section>
            {/* Task Detail Dialog */}
            <Dialog open={!!selectedTask} onOpenChange={(_, d) => { if (!d.open) setSelectedTask(null); }}>
                <DialogSurface>
                    <DialogBody>
                        <DialogTitle>
                            <Text size={500} weight="semibold">
                                {selectedTask?.taskName}
                            </Text>
                        </DialogTitle>
                        <div style={{ marginTop: 8, marginBottom: 8 }}>
                            <Text size={400} block>
                                <b>Project:</b> {selectedTask?.projectName}
                            </Text>
                            <Text size={400} block>
                                <b>Assigned to:</b> {selectedTask?.assignedUser}
                            </Text>
                            <Text size={400} block>
                                <b>Start:</b> {selectedTask ? formatDate(selectedTask.start) : ""}
                            </Text>
                            <Text size={400} block>
                                <b>End:</b> {selectedTask ? formatDate(selectedTask.end) : ""}
                            </Text>
                            {selectedTask?.task?.cat_taskstatus !== undefined && (
                                <Text size={400} block>
                                    <b>Status:</b> {selectedTask.task["cat_taskstatus@OData.Community.Display.V1.FormattedValue"] || selectedTask.task.cat_taskstatus}
                                </Text>
                            )}
                            {selectedTask?.task?.cat_priority !== undefined && (
                                <Text size={400} block>
                                    <b>Priority:</b> {selectedTask.task["cat_priority@OData.Community.Display.V1.FormattedValue"] || selectedTask.task.cat_priority}
                                </Text>
                            )}
                        </div>
                        <DialogActions>
                            <Button appearance="primary" onClick={() => setSelectedTask(null)}>
                                Close
                            </Button>
                        </DialogActions>
                    </DialogBody>
                </DialogSurface>
            </Dialog>
        </div>
    );
};

export default GeneratedComponent;
import React, { useEffect, useState } from "react";
import {
  Card,
  CardHeader,
  Text,
  Button,
  makeStyles,
  tokens,
} from "@fluentui/react-components";
import {
  ArrowLeftRegular,
  CopyRegular,
  NavigationRegular,
  DismissRegular,
  SaveRegular,
} from "@fluentui/react-icons";
import type {
  GeneratedComponentProps,
  ReadableTableRow,
  cat_uxcatalog,
  cat_promptcatalog,
  cat_appcatalog,
  cat_usecasecatalog,
  QueryTableOptions,
} from "./RuntimeTypes";

const useStyles = makeStyles({
  container: {
    display: "flex",
    flexDirection: "column",
    width: "100%",
    height: "100%",
    boxSizing: "border-box",
    backgroundColor: tokens.colorNeutralBackground1,
    color: tokens.colorNeutralForeground1,
    overflow: "hidden",
  },
  headerBar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: `${tokens.spacingVerticalM} ${tokens.spacingHorizontalL}`,
    background: "linear-gradient(180deg, #1a1a1a 0%, #000000 100%)",
    boxShadow: tokens.shadow8,
    borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
    position: "relative",
    zIndex: 1001,
  },
  backButton: {
    position: "absolute",
    left: tokens.spacingHorizontalL,
    color: "white",
  },
  hamburgerButton: {
    position: "absolute",
    left: tokens.spacingHorizontalL,
    color: "white",
  },
  headerRight: {
    position: "absolute",
    right: tokens.spacingHorizontalL,
    display: "flex",
    alignItems: "center",
    gap: tokens.spacingHorizontalS,
  },
  logo: { height: "40px", width: "auto" },
  contentArea: {
    display: "flex",
    flex: 1,
    overflow: "hidden",
    position: "relative",
    height: "calc(100% - 64px)",
  },
  sidebar: {
    position: "fixed",
    top: 0,
    left: 0,
    height: "100%",
    width: "240px",
    background: "linear-gradient(180deg, #1a1a1a 0%, #000000 100%)",
    color: "white",
    padding: tokens.spacingHorizontalM,
    display: "flex",
    flexDirection: "column",
    gap: tokens.spacingVerticalS,
    boxShadow: tokens.shadow16,
    transform: "translateX(-100%)",
    transition: "transform 0.3s ease-in-out",
    zIndex: 1100,
  },
  sidebarOpen: { transform: "translateX(0)" },
  sidebarHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: tokens.spacingVerticalM,
  },
  sidebarItem: { justifyContent: "flex-start", color: "white", textAlign: "left" },
  sidebarItemActive: {
    backgroundColor: tokens.colorBrandBackground,
    color: tokens.colorNeutralForegroundOnBrand,
  },
  overlay: {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0,0,0,0.5)",
    zIndex: 999,
    opacity: 0,
    pointerEvents: "none",
    transition: "opacity 0.3s ease-in-out",
  },
  overlayVisible: { opacity: 1, pointerEvents: "auto" },
  mainContent: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    overflow: "hidden",
    height: "100%",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, minmax(450px, 1fr))",
    gap: tokens.spacingHorizontalL,
    width: "100%",
    flex: 1,
    overflowY: "auto",
    padding: tokens.spacingHorizontalL,
    alignItems: "stretch",
    height: "100%",
    "@media (max-width: 1024px)": {
      gridTemplateColumns: "repeat(2, minmax(450px, 1fr))",
    },
    "@media (max-width: 600px)": {
      gridTemplateColumns: "repeat(1, minmax(450px, 1fr))",
    },
  },
  card: {
    cursor: "pointer",
    transition: "transform 0.3s ease, box-shadow 0.3s ease",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    background: tokens.colorNeutralBackground1,
    borderRadius: tokens.borderRadiusLarge,
    boxShadow: tokens.shadow4,
    padding: tokens.spacingHorizontalM,
    height: "100%",
    "&:hover": { transform: "translateY(-4px)", boxShadow: tokens.shadow16 },
  },
  tileFixedHeight: {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  img: { width: "100%", height: "100%", objectFit: "contain" },
  promptPageContainer: {
    display: "flex",
    flexDirection: "row",
    gap: tokens.spacingHorizontalXL,
    padding: tokens.spacingHorizontalL,
    flex: 1,
    overflow: "hidden",
    "@media (max-width: 768px)": { flexDirection: "column" },
  },
  promptImagePanel: {
    flex: "1 1 50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: tokens.colorNeutralBackground2,
    borderRadius: tokens.borderRadiusLarge,
    overflow: "hidden",
    boxShadow: tokens.shadow8,
    position: "relative",
  },
  downloadButton: {
    position: "absolute",
    top: tokens.spacingVerticalS,
    right: tokens.spacingHorizontalS,
    zIndex: 2,
  },
  ladderContainer: {
    flex: "1 1 50%",
    display: "flex",
    flexDirection: "column",
    gap: tokens.spacingVerticalXL,
    overflowY: "auto",
    paddingRight: tokens.spacingHorizontalM,
  },
  stepRow: {
    display: "flex",
    alignItems: "flex-start",
    gap: tokens.spacingHorizontalM,
    position: "relative",
  },
  stepIndicator: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    minWidth: "40px",
  },
  stepCircle: {
    width: "32px",
    height: "32px",
    borderRadius: "50%",
    backgroundColor: tokens.colorBrandBackground,
    color: tokens.colorNeutralForegroundOnBrand,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: tokens.fontWeightSemibold,
    boxShadow: tokens.shadow4,
    zIndex: 1,
  },
  stepLine: {
    flex: 1,
    width: "2px",
    backgroundColor: tokens.colorNeutralStroke2,
    marginTop: tokens.spacingVerticalS,
  },
  promptCard: {
    flex: 1,
    padding: tokens.spacingHorizontalL,
    borderRadius: tokens.borderRadiusLarge,
    background: "rgba(255,255,255,0.05)",
    backdropFilter: "blur(10px)",
    boxShadow: tokens.shadow8,
    transition: "transform 0.3s ease, box-shadow 0.3s ease",
    display: "flex",
    flexDirection: "column",
    gap: tokens.spacingVerticalS,
    color: tokens.colorNeutralForeground3,
    "&:hover": { transform: "translateY(-4px)", boxShadow: tokens.shadow16 },
  },
  promptTitle: {
    fontSize: tokens.fontSizeBase600,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground3,
  },
  promptDescription: {
    fontSize: tokens.fontSizeBase300,
    marginTop: tokens.spacingVerticalS,
    color: tokens.colorNeutralForeground3,
  },
  promptContent: {
    fontSize: tokens.fontSizeBase200,
    fontStyle: "italic",
    marginTop: tokens.spacingVerticalM,
    color: tokens.colorNeutralForeground3,
  },
  copyButton: { alignSelf: "flex-end", marginTop: tokens.spacingVerticalS },
  paginationControls: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    gap: tokens.spacingHorizontalM,
    padding: tokens.spacingVerticalM,
    borderTop: `1px solid ${tokens.colorNeutralStroke2}`,
  },
  iframeFullScreenContainer: {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: tokens.colorNeutralBackground1,
    zIndex: 2000,
    display: "flex",
    flexDirection: "column",
  },
  iframeFullScreen: { flex: 1, border: "none", width: "100%", height: "100%" },
  iframeBackButton: {
    position: "absolute",
    top: tokens.spacingVerticalM,
    left: tokens.spacingHorizontalM,
    zIndex: 2001,
  },
});

function getImageUrl(tablePlural: string, rowId: string, imageCol: string): string {
  const org =
    (window as any).Xrm?.Utility?.getGlobalContext?.().getClientUrl?.() || "";
  return `${org}/api/data/v9.2/${tablePlural}(${rowId})/${imageCol}/$value?size=full`;
}

const GeneratedComponent = ({ dataApi }: GeneratedComponentProps) => {
  const styles = useStyles();
  const [uxCatalog, setUxCatalog] = useState<ReadableTableRow<cat_uxcatalog>[]>([]);
  const [selectedUx, setSelectedUx] = useState<ReadableTableRow<cat_uxcatalog> | null>(null);
  const [prompts, setPrompts] = useState<ReadableTableRow<cat_promptcatalog>[]>([]);
  const [useCases, setUseCases] = useState<ReadableTableRow<cat_usecasecatalog>[]>([]);
  const [apps, setApps] = useState<ReadableTableRow<cat_appcatalog>[]>([]);
  const [selectedApp, setSelectedApp] = useState<ReadableTableRow<cat_appcatalog> | null>(null);
  const [activeNav, setActiveNav] = useState<"genpages" | "usecases" | "appcatalog">("genpages");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;
  const totalPages = Math.ceil(uxCatalog.length / pageSize);
  const paginatedUxCatalog = uxCatalog.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const [currentAppPage, setCurrentAppPage] = useState(1);
  const appPageSize = 6;
  const totalAppPages = Math.ceil(apps.length / appPageSize);
  const paginatedApps = apps.slice((currentAppPage - 1) * appPageSize, currentAppPage * appPageSize);

  useEffect(() => {
    const loadData = async () => {
      const uxQuery: QueryTableOptions<cat_uxcatalog> = {
        select: [
          "cat_name",
          "cat_description",
          "cat_genuximage",
          "cat_uxcatalogid",
          "_cat_usecase_value",
          "cat_uxpagelink",
        ],
      };
      const uxResult = await dataApi.queryTable("cat_uxcatalog", uxQuery);
      setUxCatalog(uxResult.rows);

      const ucQuery: QueryTableOptions<cat_usecasecatalog> = {
        select: [
          "cat_usecasecatalogid",
          "cat_name",
          "cat_description",
          "cat_usecaseimage",
          "cat_githubrepo",
        ],
      };
      const ucResult = await dataApi.queryTable("cat_usecasecatalog", ucQuery);
      setUseCases(ucResult.rows);

      const appQuery: QueryTableOptions<cat_appcatalog> = {
        select: [
          "cat_appcatalogid",
          "cat_name",
          "cat_description",
          "cat_applogo",
          "cat_applinks",
        ],
      };
      const appResult = await dataApi.queryTable("cat_appcatalog", appQuery);
      setApps(appResult.rows);
    };
    loadData();
  }, [dataApi]);

  const handleChooseUx = async (ux: ReadableTableRow<cat_uxcatalog>) => {
    setSelectedUx(ux);
    const query: QueryTableOptions<cat_promptcatalog> = {
      select: [
        "cat_name",
        "cat_description",
        "cat_promptorder",
        "cat_promptcatalogid",
        "_cat_genux_value",
      ],
      filter: `_cat_genux_value eq '/cat_uxcatalog(${ux.cat_uxcatalogid})'`,
      orderBy: "cat_promptorder asc",
    };
    const result = await dataApi.queryTable("cat_promptcatalog", query);
    setPrompts(result.rows);
    setSidebarOpen(false);
  };

  const handleChooseApp = (app: ReadableTableRow<cat_appcatalog>) => {
    setSelectedApp(app);
    setSidebarOpen(false);
  };

  const handleBack = () => {
    if (activeNav === "genpages") {
      setSelectedUx(null);
      setPrompts([]);
    } else if (activeNav === "appcatalog") {
      setSelectedApp(null);
    }
  };

  const handleDownloadImage = (ux: ReadableTableRow<cat_uxcatalog>) => {
    const imageUrl = getImageUrl("cat_uxcatalogs", ux.cat_uxcatalogid, "cat_genuximage");
    const link = document.createElement("a");
    link.href = imageUrl;
    link.download = `${ux.cat_name || "ux-image"}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePlayPage = () => {
    if (selectedUx?.cat_uxpagelink) {
      window.open(selectedUx.cat_uxpagelink, "_blank");
    } else {
      console.warn("No UXPageLink available for this UX");
    }
  };

  return (
    <div className={styles.container}>
      {!(selectedApp && activeNav === "appcatalog") && (
        <div className={styles.headerBar}>
          {(selectedUx && activeNav === "genpages") ? (
            <Button
              appearance="subtle"
              icon={<ArrowLeftRegular />}
              onClick={handleBack}
              className={styles.backButton}
            >
              Back
            </Button>
          ) : (
            <Button
              appearance="subtle"
              icon={<NavigationRegular />}
              onClick={() => setSidebarOpen(true)}
              className={styles.hamburgerButton}
              aria-label="Open navigation menu"
            />
          )}
          <Text size={700} weight="semibold" style={{ color: "white" }}>
            {activeNav === "genpages"
              ? selectedUx
                ? selectedUx.cat_name
                : "✨ Choose a Gen Page Experience"
              : activeNav === "usecases"
              ? "📂 Use Cases"
              : activeNav === "appcatalog"
              ? selectedApp
                ? selectedApp.cat_name
                : "📱 App Catalog"
              : ""}
          </Text>
          <div className={styles.headerRight}>
            {selectedUx && activeNav === "genpages" && (
              <Button appearance="subtle" onClick={handlePlayPage} style={{ color: "white" }}>
                ▶️ Page
              </Button>
            )}
            <img
              src="https://microsoft.github.io/powercat/images/header.png"
              alt="Modern Logo"
              className={styles.logo}
            />
          </div>
        </div>
      )}

      {/* Sidebar */}
      <div
        className={`${styles.sidebar} ${sidebarOpen ? styles.sidebarOpen : ""}`}
        role="navigation"
      >
        <div className={styles.sidebarHeader}>
          <Text weight="semibold">Navigation</Text>
          <Button
            appearance="subtle"
            icon={<DismissRegular />}
            onClick={() => setSidebarOpen(false)}
            aria-label="Close navigation menu"
          />
        </div>
        <Button
          appearance="subtle"
          className={`${styles.sidebarItem} ${activeNav === "genpages" ? styles.sidebarItemActive : ""}`}
          onClick={() => {
            setActiveNav("genpages");
            setSelectedUx(null);
            setSidebarOpen(false);
          }}
        >
          Gen Pages
        </Button>
        <Button
          appearance="subtle"
          className={`${styles.sidebarItem} ${activeNav === "usecases" ? styles.sidebarItemActive : ""}`}
          onClick={() => {
            setActiveNav("usecases");
            setSelectedUx(null);
            setSidebarOpen(false);
          }}
        >
          Use Cases
        </Button>
        <Button
          appearance="subtle"
          className={`${styles.sidebarItem} ${activeNav === "appcatalog" ? styles.sidebarItemActive : ""}`}
          onClick={() => {
            setActiveNav("appcatalog");
            setSelectedApp(null);
            setSidebarOpen(false);
          }}
        >
          App Catalog
        </Button>
      </div>

      <div
        className={`${styles.overlay} ${sidebarOpen ? styles.overlayVisible : ""}`}
        onClick={() => setSidebarOpen(false)}
      />

      <div className={styles.contentArea}>
        <div className={styles.mainContent}>
          {activeNav === "genpages" ? (
            !selectedUx ? (
              <>
                <div className={styles.grid}>
                  {paginatedUxCatalog.map((ux) => (
                    <Card
                      key={ux.cat_uxcatalogid}
                      className={`${styles.card} ${styles.tileFixedHeight}`}
                      onClick={() => handleChooseUx(ux)}
                    >
                      <div
                        style={{
                          width: "100%",
                          aspectRatio: "16/9",
                          overflow: "hidden",
                          borderRadius: tokens.borderRadiusMedium,
                        }}
                      >
                        {ux.cat_genuximage ? (
                          <img
                            src={getImageUrl("cat_uxcatalogs", ux.cat_uxcatalogid, "cat_genuximage")}
                            alt={ux.cat_name}
                            className={styles.img}
                          />
                        ) : (
                          <Text>No Image</Text>
                        )}
                      </div>
                      <CardHeader
                        header={<Text weight="semibold">{ux.cat_name}</Text>}
                        description={<Text size={300} truncate>{ux.cat_description}</Text>}
                      />
                    </Card>
                  ))}
                </div>
                {totalPages > 1 && (
                  <div className={styles.paginationControls}>
                    <Button
                      appearance="secondary"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((p) => p - 1)}
                    >
                      Previous
                    </Button>
                    <Text>Page {currentPage} of {totalPages}</Text>
                    <Button
                      appearance="secondary"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage((p) => p + 1)}
                    >
                      Next
                    </Button>
                  </div>
                )}
              </>
            ) : (
              <div className={styles.promptPageContainer}>
                <div className={styles.promptImagePanel}>
                  {selectedUx.cat_genuximage ? (
                    <>
                      <Button
                        appearance="primary"
                        size="small"
                        icon={<SaveRegular />}
                        className={styles.downloadButton}
                        onClick={() => handleDownloadImage(selectedUx)}
                      >
                        Save image
                      </Button>
                      <img
                        src={getImageUrl("cat_uxcatalogs", selectedUx.cat_uxcatalogid, "cat_genuximage")}
                        alt={selectedUx.cat_name}
                        className={styles.img}
                      />
                    </>
                  ) : (
                    <Text>No Image</Text>
                  )}
                </div>
                <div className={styles.ladderContainer}>
                  {prompts.map((p, idx) => (
                    <div key={p.cat_promptcatalogid} className={styles.stepRow}>
                      <div className={styles.stepIndicator}>
                        <div className={styles.stepCircle}>{idx + 1}</div>
                        {idx !== prompts.length - 1 && <div className={styles.stepLine}></div>}
                      </div>
                      <div className={styles.promptCard}>
                        <Text className={styles.promptTitle}>Prompt {idx + 1}</Text>
                        <Text className={styles.promptDescription}>{p.cat_name}</Text>
                        {/* No prompt text column in definition, so only description shown */}
                        <Button
                          appearance="subtle"
                          size="small"
                          icon={<CopyRegular />}
                          onClick={async () => {
                            await navigator.clipboard.writeText(p.cat_description || "");
                          }}
                        >
                          Copy
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          ) : activeNav === "usecases" ? (
            <div className={styles.grid}>
              {useCases.map((uc) => (
                <Card
                  key={uc.cat_usecasecatalogid}
                  className={`${styles.card} ${styles.tileFixedHeight}`}
                >
                  <div
                    style={{
                      width: "100%",
                      aspectRatio: "16/9",
                      overflow: "hidden",
                      borderRadius: tokens.borderRadiusMedium,
                    }}
                  >
                    {uc.cat_usecaseimage ? (
                      <img
                        src={getImageUrl("cat_usecasecatalogs", uc.cat_usecasecatalogid, "cat_usecaseimage")}
                        alt={uc.cat_name}
                        className={styles.img}
                      />
                    ) : (
                      <Text>No Image</Text>
                    )}
                  </div>
                  <CardHeader
                    header={<Text weight="semibold">{uc.cat_name}</Text>}
                    description={
                      <div
                        style={{
                          fontSize: tokens.fontSizeBase300,
                          color: tokens.colorNeutralForeground3,
                          marginTop: tokens.spacingVerticalM,
                        }}
                        dangerouslySetInnerHTML={{ __html: uc.cat_description || "" }}
                      />
                    }
                  />
                  {uc.cat_githubrepo && (
                    <Button
                      appearance="secondary"
                      style={{ marginTop: tokens.spacingVerticalS }}
                      onClick={() => window.open(uc.cat_githubrepo, "_blank")}
                    >
                      Github Repo
                    </Button>
                  )}
                </Card>
              ))}
            </div>
          ) : !selectedApp ? (
            <>
              <div className={styles.grid}>
                {paginatedApps.length === 0 ? (
                  <Text>No apps found in catalog.</Text>
                ) : (
                  paginatedApps.map((app) => (
                    <Card
                      key={app.cat_appcatalogid}
                      className={`${styles.card} ${styles.tileFixedHeight}`}
                      onClick={() => handleChooseApp(app)}
                    >
                      <div
                        style={{
                          width: "100%",
                          aspectRatio: "16/9",
                          overflow: "hidden",
                          borderRadius: tokens.borderRadiusMedium,
                        }}
                      >
                        {app.cat_applogo ? (
                          <img
                            src={getImageUrl("cat_appcatalogs", app.cat_appcatalogid, "cat_applogo")}
                            alt={app.cat_name}
                            className={styles.img}
                          />
                        ) : (
                          <Text>No Image</Text>
                        )}
                      </div>
                      <CardHeader
                        header={<Text weight="semibold">{app.cat_name}</Text>}
                        description={<Text size={300} truncate>{app.cat_description}</Text>}
                      />
                    </Card>
                  ))
                )}
              </div>
              {totalAppPages > 1 && (
                <div className={styles.paginationControls}>
                  <Button
                    appearance="secondary"
                    disabled={currentAppPage === 1}
                    onClick={() => setCurrentAppPage((p) => p - 1)}
                  >
                    Previous
                  </Button>
                  <Text>Page {currentAppPage} of {totalAppPages}</Text>
                  <Button
                    appearance="secondary"
                    disabled={currentAppPage === totalAppPages}
                    onClick={() => setCurrentAppPage((p) => p + 1)}
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className={styles.iframeFullScreenContainer}>
              <Button
                appearance="subtle"
                icon={<ArrowLeftRegular />}
                onClick={handleBack}
                className={styles.iframeBackButton}
              >
                Back
              </Button>
              <iframe
                src={selectedApp.cat_applinks}
                title={selectedApp.cat_name}
                className={styles.iframeFullScreen}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GeneratedComponent;
import React, { useEffect, useState, useMemo, useRef } from "react";
import {
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn,
    Input,
    Text,
    Button,
    Tooltip,
    Dropdown,
    Option,
    Dialog,
    DialogSurface,
    DialogBody,
    DialogTitle,
    DialogActions,
    DialogTrigger,
    Checkbox,
    useDialogTrigger,
} from "@fluentui/react-components";
import {
    FilterRegular,
    SettingsRegular,
    MoreHorizontalRegular,
    AddRegular,
    DeleteRegular,
    CalendarRegular,
    PersonRegular,
    QuestionRegular,
} from "@fluentui/react-icons";
import type {
    GeneratedComponentProps,
    cat_task,
    cat_project,
    systemuser,
    ReadableTableRow,
    WritableTableRow,
    QueryTableOptions,
} from "./RuntimeTypes";

// ------- Utility functions ------ //

// Status render mapping
function renderStatusBadge(status: string | undefined, rawStatus: number | undefined) {
    let colors = {
        "Not Started": { bg: "#c8c8c8", fg: "#2e2e2e" },
        "In Progress": { bg: "#FFEA93", fg: "#856404" },
        "Completed": { bg: "#88eba0", fg: "#155724" },
        "Blocked": { bg: "#f7b4b2", fg: "#721c24" },
    };
    const style: React.CSSProperties = {
        display: "inline-block",
        padding: "4px 18px",
        borderRadius: "16px",
        fontWeight: 500,
        fontSize: "14px",
        background: colors[status || "Not Started"]?.bg || "#c8c8c8",
        color: colors[status || "Not Started"]?.fg || "#1b1b1b",
        textAlign: "center",
        minWidth: "90px",
        boxSizing: "border-box",
        userSelect: "none",
        letterSpacing: "0.01em",
    };
    return (
        <span style={style}>{status || "Unknown"}</span>
    );
}

// Priority render mapping
function renderPriorityBadge(priority: string | undefined, rawPriority: number | undefined) {
    const map = {
        Low: { bg: "#b9e2fa", fg: "#0971ab" },
        Medium: { bg: "#e7f281", fg: "#a5ad1a" },
        High: { bg: "#fbe6a2", fg: "#ce6d1b" },
        Urgent: { bg: "#ff6f6f", fg: "#fff" },
    };
    const style: React.CSSProperties = {
        display: "inline-block",
        padding: "4px 18px",
        borderRadius: "16px",
        fontWeight: 500,
        fontSize: "14px",
        background: map[priority || "Medium"]?.bg,
        color: map[priority || "Medium"]?.fg,
        minWidth: "80px",
        boxSizing: "border-box",
        textAlign: "center",
        userSelect: "none",
        letterSpacing: "0.01em",
    };
    return (
        <span style={style}>{priority || "Medium"}</span>
    );
}

// Format Date utility
function formatDate(date: Date | string | undefined): string {
    if (!date) return "-";
    if (typeof date === "string" && date.length > 0) {
        const d = new Date(date);
        if (!isNaN(d.getTime())) {
            return d.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
        }
        return date;
    }
    if (date instanceof Date) {
        return date.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
    }
    return "-";
}

// ------- Main Task grid component with inline editing ------ //

const ALL_GRID_COLUMNS = [
    { id: "cat_taskname", label: "Title" },
    { id: "cat_description", label: "Description" },
    { id: "_cat_project_value", label: "Project" },
    { id: "cat_priority", label: "Priority" },
    { id: "cat_taskstatus", label: "Status" },
    { id: "cat_estimatedhours", label: "Est. Hrs" },
    { id: "cat_daysoverdue", label: "Actual Hrs" },
    { id: "cat_deadline", label: "Due date" },
    // "actions" column removed
];

const TaskGrid = ({
    dataApi,
    projectIdToName,
    projectOptions,
    priorityChoices,
    statusChoices,
    refreshProjects,
    visibleColumnIds,
}: {
    dataApi: GeneratedComponentProps["dataApi"];
    projectIdToName: Record<string, string>;
    projectOptions: { label: string; value: string }[];
    priorityChoices: { label: string; value: number }[];
    statusChoices: { label: string; value: number }[];
    refreshProjects: () => void;
    visibleColumnIds: string[];
}) => {
    const [tasks, setTasks] = useState<ReadableTableRow<cat_task>[]>([]);
    const [filterText, setFilterText] = useState("");
    const [loading, setLoading] = useState(false);

    // Editing state: { rowId, columnId }
    const [editingCell, setEditingCell] = useState<{ rowId: string; columnId: string } | null>(null);
    // Value being edited
    const [editValue, setEditValue] = useState<any>(null);
    // For focusing input after entering edit mode
    const inputRef = useRef<HTMLInputElement | null>(null);

    // Fetch tasks
    useEffect(() => {
        setLoading(true);
        const fetchTasks = async () => {
            const query: QueryTableOptions<cat_task> = {
                select: [
                    "cat_taskid",
                    "cat_taskname",
                    "cat_description",
                    "cat_deadline",
                    "cat_estimatedhours",
                    "cat_priority",
                    "cat_taskstatus",
                    "cat_daysoverdue",
                    "_cat_project_value",
                    "statecode",
                    "statuscode",
                ],
                pageSize: 100,
                orderBy: "cat_deadline asc",
            };
            const result = await dataApi.queryTable("cat_task", query);
            setTasks(result.rows);
            setLoading(false);
        };
        fetchTasks();
    }, [dataApi]);

    // Filtered/searchable rows
    const filteredRows = useMemo(() => {
        const s = filterText.trim().toLowerCase();
        if (!s) return tasks;
        return tasks.filter(t =>
            [
                t.cat_taskname,
                t.cat_description,
                t["_cat_project_value@OData.Community.Display.V1.FormattedValue"],
                t["cat_priority@OData.Community.Display.V1.FormattedValue"],
                t["cat_taskstatus@OData.Community.Display.V1.FormattedValue"],
            ]
                .map((field) => (field ? field.toLowerCase() : ""))
                .some((v) => v.includes(s))
        );
    }, [tasks, filterText]);

    // Helper: get row by id
    const getRowById = (rowId: string) => tasks.find(t => t.cat_taskid === rowId);

    // Helper: update row in local state
    const updateRowInState = (rowId: string, updated: Partial<cat_task>) => {
        setTasks(prev =>
            prev.map(row =>
                row.cat_taskid === rowId ? { ...row, ...updated } : row
            )
        );
    };

    // Save edit (calls API)
    const saveEdit = async (rowId: string, columnId: string, value: any) => {
        const row = getRowById(rowId);
        if (!row) return;
        let update: Partial<WritableTableRow<cat_task>> = {};
        // Map columnId to field
        switch (columnId) {
            case "cat_taskname":
            case "cat_description":
                update[columnId] = value;
                break;
            case "cat_estimatedhours":
            case "cat_daysoverdue":
                update[columnId] = value === "" ? null : Number(value);
                break;
            case "cat_deadline":
                update[columnId] = value ? new Date(value) : null;
                break;
            case "_cat_project_value":
                update[columnId] = value;
                break;
            case "cat_priority":
                update[columnId] = value;
                break;
            case "cat_taskstatus":
                update[columnId] = value;
                break;
            default:
                break;
        }
        try {
            await dataApi.updateRow("cat_task", rowId, update as WritableTableRow<cat_task>);
            // Refetch row to get formatted values
            const updatedRow = await dataApi.retrieveRow("cat_task", {
                id: rowId,
                select: [
                    "cat_taskid",
                    "cat_taskname",
                    "cat_description",
                    "cat_deadline",
                    "cat_estimatedhours",
                    "cat_priority",
                    "cat_taskstatus",
                    "cat_daysoverdue",
                    "_cat_project_value",
                    "statecode",
                    "statuscode",
                ],
            });
            updateRowInState(rowId, updatedRow);
            // If project was changed, refresh project mapping
            if (columnId === "_cat_project_value") {
                refreshProjects();
            }
        } catch (e) {
            // Optionally show error
        }
    };

    // Handle cell double click to enter edit mode
    const handleCellDoubleClick = (rowId: string, columnId: string, currentValue: any) => {
        setEditingCell({ rowId, columnId });
        setEditValue(currentValue);
        setTimeout(() => {
            if (inputRef.current) inputRef.current.focus();
        }, 0);
    };

    // Handle edit input change
    const handleEditChange = (value: any) => {
        setEditValue(value);
    };

    // Handle blur or Enter to save
    const handleEditSave = async () => {
        if (editingCell) {
            await saveEdit(editingCell.rowId, editingCell.columnId, editValue);
            setEditingCell(null);
            setEditValue(null);
        }
    };

    // Handle Esc to cancel
    const handleEditCancel = () => {
        setEditingCell(null);
        setEditValue(null);
    };

    // Table columns definitions
    const allColumns = {
        cat_taskname: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskname",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Title</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "cat_taskname";
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "cat_taskname", item.cat_taskname)}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Input
                                ref={inputRef}
                                value={editValue ?? ""}
                                onChange={(e, d) => handleEditChange(d.value)}
                                onBlur={handleEditSave}
                                onKeyDown={e => {
                                    if (e.key === "Enter") handleEditSave();
                                    if (e.key === "Escape") handleEditCancel();
                                }}
                                size="small"
                                style={{ minWidth: 120 }}
                                aria-label="Edit task name"
                            />
                        ) : (
                            item.cat_taskname
                        )}
                    </TableCellLayout>
                );
            },
        }),
        cat_description: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_description",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Description</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "cat_description";
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "cat_description", item.cat_description)}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Input
                                ref={inputRef}
                                value={editValue ?? ""}
                                onChange={(e, d) => handleEditChange(d.value)}
                                onBlur={handleEditSave}
                                onKeyDown={e => {
                                    if (e.key === "Enter") handleEditSave();
                                    if (e.key === "Escape") handleEditCancel();
                                }}
                                size="small"
                                style={{ minWidth: 120 }}
                                aria-label="Edit description"
                            />
                        ) : (
                            item.cat_description
                        )}
                    </TableCellLayout>
                );
            },
        }),
        _cat_project_value: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "_cat_project_value",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Project</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "_cat_project_value";
                const currentValue = item._cat_project_value;
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "_cat_project_value", currentValue)}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Dropdown
                                open
                                value={
                                    projectOptions.find(opt => opt.value === editValue)?.label ||
                                    item["_cat_project_value@OData.Community.Display.V1.FormattedValue"] ||
                                    ""
                                }
                                selectedOptions={editValue ? [editValue] : []}
                                onOptionSelect={(_, data) => {
                                    handleEditChange(data.optionValue);
                                    setTimeout(handleEditSave, 0);
                                }}
                                onBlur={handleEditSave}
                                aria-label="Select project"
                                style={{ minWidth: 120 }}
                                size="small"
                            >
                                {projectOptions.map(opt => (
                                    <Option key={opt.value} value={opt.value}>
                                        {opt.label}
                                    </Option>
                                ))}
                            </Dropdown>
                        ) : (
                            item["_cat_project_value@OData.Community.Display.V1.FormattedValue"] ||
                            ""
                        )}
                    </TableCellLayout>
                );
            },
        }),
        cat_priority: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_priority",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Priority</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "cat_priority";
                const currentValue = item.cat_priority;
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "cat_priority", currentValue)}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Dropdown
                                open
                                value={
                                    priorityChoices.find(opt => opt.value === editValue)?.label ||
                                    item["cat_priority@OData.Community.Display.V1.FormattedValue"] ||
                                    ""
                                }
                                selectedOptions={editValue !== undefined ? [String(editValue)] : []}
                                onOptionSelect={(_, data) => {
                                    handleEditChange(Number(data.optionValue));
                                    setTimeout(handleEditSave, 0);
                                }}
                                onBlur={handleEditSave}
                                aria-label="Select priority"
                                style={{ minWidth: 100 }}
                                size="small"
                            >
                                {priorityChoices.map(opt => (
                                    <Option key={opt.value} value={String(opt.value)}>
                                        {opt.label}
                                    </Option>
                                ))}
                            </Dropdown>
                        ) : (
                            renderPriorityBadge(
                                item["cat_priority@OData.Community.Display.V1.FormattedValue"] as string | undefined,
                                item.cat_priority
                            )
                        )}
                    </TableCellLayout>
                );
            },
        }),
        cat_taskstatus: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskstatus",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Status</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "cat_taskstatus";
                const currentValue = item.cat_taskstatus;
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "cat_taskstatus", currentValue)}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Dropdown
                                open
                                value={
                                    statusChoices.find(opt => opt.value === editValue)?.label ||
                                    item["cat_taskstatus@OData.Community.Display.V1.FormattedValue"] ||
                                    ""
                                }
                                selectedOptions={editValue !== undefined ? [String(editValue)] : []}
                                onOptionSelect={(_, data) => {
                                    handleEditChange(Number(data.optionValue));
                                    setTimeout(handleEditSave, 0);
                                }}
                                onBlur={handleEditSave}
                                aria-label="Select status"
                                style={{ minWidth: 100 }}
                                size="small"
                            >
                                {statusChoices.map(opt => (
                                    <Option key={opt.value} value={String(opt.value)}>
                                        {opt.label}
                                    </Option>
                                ))}
                            </Dropdown>
                        ) : (
                            renderStatusBadge(
                                item["cat_taskstatus@OData.Community.Display.V1.FormattedValue"] as string | undefined,
                                item.cat_taskstatus
                            )
                        )}
                    </TableCellLayout>
                );
            },
        }),
        cat_estimatedhours: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_estimatedhours",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Est. Hrs</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "cat_estimatedhours";
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "cat_estimatedhours", item.cat_estimatedhours ?? "")}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Input
                                ref={inputRef}
                                value={editValue ?? ""}
                                onChange={(e, d) => handleEditChange(d.value)}
                                onBlur={handleEditSave}
                                onKeyDown={e => {
                                    if (e.key === "Enter") handleEditSave();
                                    if (e.key === "Escape") handleEditCancel();
                                }}
                                size="small"
                                type="number"
                                min={0}
                                style={{ minWidth: 60 }}
                                aria-label="Edit estimated hours"
                            />
                        ) : (
                            item.cat_estimatedhours != null ? item.cat_estimatedhours.toString() : "-"
                        )}
                    </TableCellLayout>
                );
            },
        }),
        cat_daysoverdue: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_daysoverdue",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Actual Hrs</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "cat_daysoverdue";
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "cat_daysoverdue", item.cat_daysoverdue ?? "")}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Input
                                ref={inputRef}
                                value={editValue ?? ""}
                                onChange={(e, d) => handleEditChange(d.value)}
                                onBlur={handleEditSave}
                                onKeyDown={e => {
                                    if (e.key === "Enter") handleEditSave();
                                    if (e.key === "Escape") handleEditCancel();
                                }}
                                size="small"
                                type="number"
                                min={0}
                                style={{ minWidth: 60 }}
                                aria-label="Edit actual hours"
                            />
                        ) : (
                            item.cat_daysoverdue != null ? item.cat_daysoverdue.toString() : "-"
                        )}
                    </TableCellLayout>
                );
            },
        }),
        cat_deadline: createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_deadline",
            renderHeaderCell: () => (
                <Text size={400} weight="bold" style={{ padding: 4 }}>Due date</Text>
            ),
            renderCell: (item) => {
                const isEditing = editingCell && editingCell.rowId === item.cat_taskid && editingCell.columnId === "cat_deadline";
                const dateStr = item.cat_deadline ? new Date(item.cat_deadline).toISOString().slice(0, 10) : "";
                return (
                    <TableCellLayout
                        onDoubleClick={() => handleCellDoubleClick(item.cat_taskid, "cat_deadline", dateStr)}
                        style={{ cursor: "pointer" }}
                    >
                        {isEditing ? (
                            <Input
                                ref={inputRef}
                                value={editValue ?? ""}
                                onChange={(e, d) => handleEditChange(d.value)}
                                onBlur={handleEditSave}
                                onKeyDown={e => {
                                    if (e.key === "Enter") handleEditSave();
                                    if (e.key === "Escape") handleEditCancel();
                                }}
                                size="small"
                                type="date"
                                style={{ minWidth: 120 }}
                                aria-label="Edit due date"
                            />
                        ) : (
                            formatDate(item.cat_deadline)
                        )}
                    </TableCellLayout>
                );
            },
        }),
        // "actions" column removed
    };

    // Only show columns that are in visibleColumnIds
    const columns = visibleColumnIds.map(id => allColumns[id]);

    // --- Render ---
    return (
        <div style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            boxSizing: "border-box",
            width: "100%",
            minHeight: 0,
        }}>
            <div style={{ flex: 1, minHeight: 0, overflow: "auto", boxSizing: "border-box", borderRadius: "8px" }}>
                <DataGrid
                    items={filteredRows}
                    columns={columns}
                    selectionMode="multiselect"
                    focusMode="composite"
                    getRowId={i => i.cat_taskid}
                    style={{
                        background: "#fff",
                        borderRadius: "8px",
                        boxSizing: "border-box",
                        minHeight: 0,
                        boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
                    }}
                >
                    <DataGridHeader>
                        <DataGridRow selectionCell={{ checkboxIndicator: { "aria-label": "Select all tasks" } }}>
                            {({ renderHeaderCell }) => <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>}
                        </DataGridRow>
                    </DataGridHeader>
                    <DataGridBody<ReadableTableRow<cat_task>>>
                        {({ item, rowId }) => (
                            <DataGridRow<ReadableTableRow<cat_task>> key={rowId} selectionCell={{ checkboxIndicator: { "aria-label": "Select task" } }}>
                                {({ renderCell, columnId }) => (
                                    <DataGridCell>
                                        {renderCell(item)}
                                    </DataGridCell>
                                )}
                            </DataGridRow>
                        )}
                    </DataGridBody>
                </DataGrid>
                {loading && (
                    <Text size={400} style={{ marginTop: "18px", textAlign: "center", color: "#0078D4" }}>Loading tasks...</Text>
                )}
                {!loading && filteredRows.length === 0 && (
                    <Text size={400} style={{ marginTop: "18px", textAlign: "center", color: "#525252" }}>No tasks found.</Text>
                )}
            </div>
            {/* Filter bar below grid for accessibility on mobile */}
            <div style={{ marginTop: 12, maxWidth: 400 }}>
                <Input
                    placeholder="Search tasks..."
                    appearance="outline"
                    value={filterText}
                    onChange={(e, d) => setFilterText(d.value)}
                    style={{
                        width: "100%",
                        background: "#fff",
                        fontSize: "16px",
                    }}
                    aria-label="Search tasks"
                />
            </div>
        </div>
    );
};

// --- Settings Modal for Column Selection --- //
function SettingsDialog({
    open,
    onOpenChange,
    allColumns,
    selectedColumnIds,
    onChange,
}: {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    allColumns: { id: string; label: string }[];
    selectedColumnIds: string[];
    onChange: (ids: string[]) => void;
}) {
    const [localSelected, setLocalSelected] = useState<string[]>(selectedColumnIds);

    useEffect(() => {
        setLocalSelected(selectedColumnIds);
    }, [selectedColumnIds, open]);

    const handleCheckboxChange = (id: string, checked: boolean) => {
        setLocalSelected(prev =>
            checked ? [...prev, id] : prev.filter(cid => cid !== id)
        );
    };

    const handleSave = () => {
        // At least one column must be selected
        if (localSelected.length === 0) return;
        onChange(localSelected);
        onOpenChange(false);
    };

    const handleCancel = () => {
        setLocalSelected(selectedColumnIds);
        onOpenChange(false);
    };

    return (
        <Dialog open={open} onOpenChange={(_, data) => onOpenChange(data.open)}>
            <DialogSurface>
                <DialogBody>
                    <DialogTitle as="h2" style={{ fontWeight: 600, fontSize: 20 }}>
                        Customize columns
                    </DialogTitle>
                    <div style={{ marginTop: 16, marginBottom: 16, display: "flex", flexDirection: "column", gap: "10px" }}>
                        {allColumns.map(col => (
                            <Checkbox
                                key={col.id}
                                checked={localSelected.includes(col.id)}
                                onChange={(_, data) => handleCheckboxChange(col.id, data.checked === true)}
                                label={col.label}
                                shape="square"
                                size="medium"
                                aria-label={`Show ${col.label} column`}
                            />
                        ))}
                    </div>
                    <DialogActions>
                        <Button appearance="secondary" onClick={handleCancel}>
                            Cancel
                        </Button>
                        <Button appearance="primary" onClick={handleSave} disabled={localSelected.length === 0}>
                            Save
                        </Button>
                    </DialogActions>
                </DialogBody>
            </DialogSurface>
        </Dialog>
    );
}

// --- Main Component (with header, grid) --- //
const GeneratedComponent = ({ dataApi }: GeneratedComponentProps) => {
    const [projectIdToName, setProjectIdToName] = useState<Record<string, string>>({});
    const [projectOptions, setProjectOptions] = useState<{ label: string; value: string }[]>([]);
    const [priorityChoices, setPriorityChoices] = useState<{ label: string; value: number }[]>([]);
    const [statusChoices, setStatusChoices] = useState<{ label: string; value: number }[]>([]);

    // --- Fetch all projects for dropdown mapping --- //
    const fetchProjects = async () => {
        const result = await dataApi.queryTable("cat_project", {
            select: ["cat_projectid", "cat_projectname"],
            pageSize: 200,
            orderBy: "cat_projectname asc",
        });
        const map: Record<string, string> = {};
        const opts: { label: string; value: string }[] = [];
        for (const p of result.rows) {
            if (p.cat_projectid && p.cat_projectname) {
                map[p.cat_projectid] = p.cat_projectname;
                opts.push({
                    label: p.cat_projectname,
                    value: `/cat_project(${p.cat_projectid})`,
                });
            }
        }
        setProjectIdToName(map);
        setProjectOptions(opts);
    };

    useEffect(() => {
        fetchProjects();
    }, [dataApi]);

    // --- Fetch enum choices for Priority and Status --- //
    useEffect(() => {
        const fetchChoices = async () => {
            const [priority, status] = await Promise.all([
                dataApi.getChoices("cat_task-cat_priority"),
                dataApi.getChoices("cat_task-cat_taskstatus"),
            ]);
            setPriorityChoices(priority);
            setStatusChoices(status);
        };
        fetchChoices();
    }, [dataApi]);

    // --- Column selection state --- //
    const [settingsOpen, setSettingsOpen] = useState(false);
    // Default: show all columns
    const [visibleColumnIds, setVisibleColumnIds] = useState<string[]>(ALL_GRID_COLUMNS.map(c => c.id));

    // Responsive grid area sizing
    return (
        <div style={{
            flexGrow: 1,
            width: "100%",
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
            alignSelf: "stretch",
            boxSizing: "border-box",
            background: "#f8f8f8",
        }}>
            {/* Header/Toolbar */}
            <div
                style={{
                    boxSizing: "border-box",
                    width: "100%",
                    padding: "18px 30px 18px 25px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                    alignItems: "flex-start",
                    background: "linear-gradient(90deg, #219a2a 2%, #3ecd3e 100%)",
                    borderRadius: "12px 12px 0 0",
                    boxShadow: "0 3px 8px rgba(64,128,64,0.07)",
                }}
            >
                {/* Top bar: title + settings + actions */}
                <div style={{ display: "flex", width: "100%", justifyContent: "space-between", alignItems: "center", marginBottom: "6px" }}>
                    <div>
                        <Text as="h1" size={700} weight="semibold" block style={{ color: "#fff", letterSpacing: "0.02em" }}>
                            Task management
                        </Text>
                        <Text size={300} block style={{ color: "#eaffea", letterSpacing: "0.01em", marginTop: 2 }}>
                            Manage project tasks in an editable grid. Double-click any cell to edit.
                        </Text>
                    </div>
                    {/* Action/Settings area */}
                    <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
                        <Tooltip content="Settings">
                            <Button
                                appearance="subtle"
                                style={{ background: "transparent", padding: 0, minWidth: 0, height: "32px" }}
                                onClick={() => setSettingsOpen(true)}
                                aria-label="Customize columns"
                            >
                                <SettingsRegular fontSize="28px" style={{ color: "#fff", cursor: "pointer" }} />
                            </Button>
                        </Tooltip>
                        <Text size={200} style={{ color: "#fff", fontWeight: 600, marginLeft: "4px" }}>
                            Edit mode
                        </Text>
                        <Tooltip content="Add task">
                            <AddRegular fontSize="22px" style={{ color: "#fff", cursor: "pointer" }} />
                        </Tooltip>
                        <Tooltip content="Delete selected">
                            <DeleteRegular fontSize="22px" style={{ color: "#fff", cursor: "pointer" }} />
                        </Tooltip>
                    </div>
                </div>
            </div>
            {/* Settings Modal */}
            <SettingsDialog
                open={settingsOpen}
                onOpenChange={setSettingsOpen}
                allColumns={ALL_GRID_COLUMNS}
                selectedColumnIds={visibleColumnIds}
                onChange={setVisibleColumnIds}
            />
            {/* Grid area below header */}
            <div
                id="taskgrid-container"
                style={{
                    flex: 1,
                    minHeight: 0,
                    padding: "0 12px 18px 12px",
                    width: "100%",
                    background: "#f8f8f8",
                    display: "flex",
                    flexDirection: "column",
                    boxSizing: "border-box",
                    borderRadius: "0 0 12px 12px",
                }}
            >
                <TaskGrid
                    dataApi={dataApi}
                    projectIdToName={projectIdToName}
                    projectOptions={projectOptions}
                    priorityChoices={priorityChoices}
                    statusChoices={statusChoices}
                    refreshProjects={fetchProjects}
                    visibleColumnIds={visibleColumnIds}
                />
            </div>
        </div>
    );
};

export default GeneratedComponent;
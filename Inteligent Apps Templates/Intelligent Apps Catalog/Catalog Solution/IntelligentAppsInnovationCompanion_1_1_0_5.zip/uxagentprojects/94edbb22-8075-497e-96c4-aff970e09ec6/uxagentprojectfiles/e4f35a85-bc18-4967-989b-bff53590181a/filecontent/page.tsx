import React, { useEffect, useState } from 'react';
import {
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn,
    Text,
    Button,
    Switch,
    makeStyles,
    tokens,
    webLightTheme,
    webDarkTheme,
    FluentProvider
} from '@fluentui/react-components';
import { ArrowClockwiseRegular } from '@fluentui/react-icons';
import type { GeneratedComponentProps, cat_project, cat_task, ReadableTableRow, QueryTableOptions } from "./RuntimeTypes";

const useStyles = makeStyles({
    container: {
        display: "flex",
        flexDirection: "column",
        width: "100%",
        height: "100%",
        padding: tokens.spacingHorizontalM,
        boxSizing: "border-box",
        backgroundColor: tokens.colorNeutralBackground1
    },
    header: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: tokens.spacingVerticalM
    },
    content: {
        display: "flex",
        flex: 1,
        gap: tokens.spacingHorizontalM,
        overflow: "hidden"
    },
    section: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
    },
    sectionTitle: {
        marginBottom: tokens.spacingVerticalXS
    },
    gridContainer: {
        flex: 1,
        overflow: "auto"
    },
    themeToggle: {
        display: "flex",
        alignItems: "center",
        gap: tokens.spacingHorizontalS
    }
});

const GeneratedComponent: React.FC<GeneratedComponentProps> = ({ dataApi }) => {
    const styles = useStyles();
    const [projects, setProjects] = useState<ReadableTableRow<cat_project>[]>([]);
    const [tasks, setTasks] = useState<ReadableTableRow<cat_task>[]>([]);
    const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
    const [loadingProjects, setLoadingProjects] = useState(false);
    const [loadingTasks, setLoadingTasks] = useState(false);
    const [isDarkMode, setIsDarkMode] = useState(false);

    const fetchProjects = async () => {
        setLoadingProjects(true);
        try {
            const query: QueryTableOptions<cat_project> = {
                select: ["cat_projectid", "cat_projectname", "cat_startdate", "cat_enddate", "cat_projectbudget"],
                orderBy: "cat_projectname asc",
                pageSize: 50
            };
            const result = await dataApi.queryTable("cat_project", query);
            setProjects(result.rows);
        } finally {
            setLoadingProjects(false);
        }
    };

    const fetchTasks = async (projectId: string) => {
        setLoadingTasks(true);
        try {
            const query: QueryTableOptions<cat_task> = {
                select: ["cat_taskid", "cat_taskname", "cat_deadline", "cat_priority", "cat_taskstatus"],
                filter: `_cat_project_value eq '/cat_project(${projectId})'`,
                orderBy: "cat_deadline asc",
                pageSize: 50
            };
            const result = await dataApi.queryTable("cat_task", query);
            setTasks(result.rows);
        } finally {
            setLoadingTasks(false);
        }
    };

    useEffect(() => {
        fetchProjects();
    }, []);

    useEffect(() => {
        if (selectedProjectId) {
            fetchTasks(selectedProjectId);
        } else {
            setTasks([]);
        }
    }, [selectedProjectId]);

    const projectColumns = [
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_projectname",
            renderHeaderCell: () => "Project Name",
            renderCell: (item) => <TableCellLayout>{item.cat_projectname}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_startdate",
            renderHeaderCell: () => "Start Date",
            renderCell: (item) => <TableCellLayout>{item.cat_startdate ? new Date(item.cat_startdate).toLocaleDateString() : ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_enddate",
            renderHeaderCell: () => "End Date",
            renderCell: (item) => <TableCellLayout>{item.cat_enddate ? new Date(item.cat_enddate).toLocaleDateString() : ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_project>>({
            columnId: "cat_projectbudget",
            renderHeaderCell: () => "Budget",
            renderCell: (item) => <TableCellLayout>${item.cat_projectbudget?.toLocaleString()}</TableCellLayout>
        })
    ];

    const taskColumns = [
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskname",
            renderHeaderCell: () => "Task Name",
            renderCell: (item) => <TableCellLayout>{item.cat_taskname}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_deadline",
            renderHeaderCell: () => "Deadline",
            renderCell: (item) => <TableCellLayout>{item.cat_deadline ? new Date(item.cat_deadline).toLocaleDateString() : ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_priority",
            renderHeaderCell: () => "Priority",
            renderCell: (item) => <TableCellLayout>{item["cat_priority@OData.Community.Display.V1.FormattedValue"] || ""}</TableCellLayout>
        }),
        createTableColumn<ReadableTableRow<cat_task>>({
            columnId: "cat_taskstatus",
            renderHeaderCell: () => "Status",
            renderCell: (item) => <TableCellLayout>{item["cat_taskstatus@OData.Community.Display.V1.FormattedValue"] || ""}</TableCellLayout>
        })
    ];

    return (
        <FluentProvider theme={isDarkMode ? webDarkTheme : webLightTheme} style={{ width: "100%", height: "100%" }}>
            <div className={styles.container}>
                <header className={styles.header}>
                    <Text size={600} weight="semibold">Projects and Tasks</Text>
                    <div className={styles.themeToggle}>
                        <Switch
                            checked={isDarkMode}
                            onChange={(_, data) => setIsDarkMode(data.checked)}
                            label={isDarkMode ? "Dark Mode" : "Light Mode"}
                        />
                        <Button icon={<ArrowClockwiseRegular />} onClick={fetchProjects} disabled={loadingProjects}>
                            Refresh
                        </Button>
                    </div>
                </header>
                <div className={styles.content}>
                    {/* Projects Grid */}
                    <div className={styles.section}>
                        <Text weight="semibold" className={styles.sectionTitle}>Projects</Text>
                        <div className={styles.gridContainer}>
                            <DataGrid
                                items={projects}
                                columns={projectColumns}
                                selectionMode="single"
                                getRowId={(item) => item.cat_projectid}
                                onSelectionChange={(e, data) => {
                                    const selectedId = Array.from(data.selectedItems)[0] as string;
                                    setSelectedProjectId(selectedId);
                                }}
                            >
                                <DataGridHeader>
                                    <DataGridRow>
                                        {({ renderHeaderCell }) => (
                                            <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                                        )}
                                    </DataGridRow>
                                </DataGridHeader>
                                <DataGridBody<ReadableTableRow<cat_project>>>
                                    {({ item }) => (
                                        <DataGridRow key={item.cat_projectid}>
                                            {({ renderCell }) => <DataGridCell>{renderCell(item)}</DataGridCell>}
                                        </DataGridRow>
                                    )}
                                </DataGridBody>
                            </DataGrid>
                        </div>
                    </div>
                    {/* Tasks Grid */}
                    <div className={styles.section}>
                        <Text weight="semibold" className={styles.sectionTitle}>Tasks</Text>
                        <div className={styles.gridContainer}>
                            <DataGrid
                                items={tasks}
                                columns={taskColumns}
                                getRowId={(item) => item.cat_taskid}
                            >
                                <DataGridHeader>
                                    <DataGridRow>
                                        {({ renderHeaderCell }) => (
                                            <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                                        )}
                                    </DataGridRow>
                                </DataGridHeader>
                                <DataGridBody<ReadableTableRow<cat_task>>>
                                    {({ item }) => (
                                        <DataGridRow key={item.cat_taskid}>
                                            {({ renderCell }) => <DataGridCell>{renderCell(item)}</DataGridCell>}
                                        </DataGridRow>
                                    )}
                                </DataGridBody>
                            </DataGrid>
                        </div>
                    </div>
                </div>
            </div>
        </FluentProvider>
    );
};

export default GeneratedComponent;